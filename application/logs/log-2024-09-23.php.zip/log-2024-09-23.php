<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-09-23 14:44:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\xampp\htdocs\mce_campus\application\libraries\Logger.php 143
ERROR - 2024-09-23 14:44:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\xampp\htdocs\mce_campus\application\libraries\Logger.php 143
ERROR - 2024-09-23 14:44:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\xampp\htdocs\mce_campus\application\libraries\Logger.php 143
