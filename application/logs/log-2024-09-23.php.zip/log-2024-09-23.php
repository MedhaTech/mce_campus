<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-09-23 09:25:40 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-23 13:50:59 --> Query error: Unknown column 'usn' in 'where clause' - Invalid query: SELECT SUM(amount) AS total_amount
FROM `transactions`
WHERE `year` = 'II'
AND `usn` = '4MC23CB001'
AND `payment_mode` = 0
ERROR - 2024-09-23 14:44:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\xampp\htdocs\mce_campus\application\libraries\Logger.php 143
ERROR - 2024-09-23 14:44:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\xampp\htdocs\mce_campus\application\libraries\Logger.php 143
