<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-09-20 06:42:14 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 06:42:14 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 06:42:14 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 06:42:14 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 10:12:20 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-20 10:12:20 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-20 10:12:20 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-20 06:42:20 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 06:42:20 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 06:42:20 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 06:42:20 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 06:42:22 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 06:42:22 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 06:42:22 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 06:42:22 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 10:13:45 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-20 10:13:53 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-20 10:13:53 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-20 10:13:53 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-20 10:13:58 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-20 10:13:58 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-20 06:44:20 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 06:44:20 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 06:44:20 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 06:44:20 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 10:14:44 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-20 10:14:44 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-20 10:14:44 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-20 06:44:45 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 06:44:45 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 06:44:45 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 06:44:45 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 06:44:47 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 06:44:47 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 06:44:47 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 06:44:47 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 10:14:54 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-20 10:14:54 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-20 06:45:17 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 06:45:17 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 06:45:17 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 06:45:17 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 07:16:41 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 07:16:41 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 07:16:41 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 07:16:41 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 10:46:43 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-20 10:46:43 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-20 10:46:43 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-20 07:16:43 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 07:16:43 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 07:16:43 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 07:16:43 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 10:46:45 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-20 10:46:45 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-20 07:17:08 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 07:17:08 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 07:17:08 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 07:17:08 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 07:17:09 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-20 07:17:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-09-20 10:47:25 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-20 10:47:25 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-20 07:17:48 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 07:17:48 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 07:17:48 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 07:17:48 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-20 07:17:49 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-20 07:17:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-09-20 10:49:55 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-20 10:49:55 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-20 07:20:20 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-20 07:20:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-09-20 10:50:35 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-20 10:50:35 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-20 10:50:35 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-20 10:50:37 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-20 10:50:37 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-20 10:51:29 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-20 10:51:29 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-20 10:51:29 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-20 10:51:30 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-20 10:51:30 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-20 10:52:56 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-20 10:52:56 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-20 10:52:56 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-20 10:52:57 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 99
ERROR - 2024-09-20 10:55:30 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-20 10:55:30 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-20 10:55:30 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-20 16:10:09 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 99
ERROR - 2024-09-20 12:40:41 --> 404 Page Not Found: Admin/reports
ERROR - 2024-09-20 16:10:44 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 99
ERROR - 2024-09-20 16:16:21 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 99
ERROR - 2024-09-20 16:32:06 --> Severity: error --> Exception: Call to undefined method Admin::courses() C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 141
ERROR - 2024-09-20 16:32:51 --> Severity: Warning --> Undefined variable $course_options C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 30
ERROR - 2024-09-20 16:32:51 --> Severity: Warning --> Undefined variable $course C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 30
ERROR - 2024-09-20 16:32:51 --> Severity: Warning --> Undefined variable $quota C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 37
ERROR - 2024-09-20 16:32:51 --> Severity: Warning --> Undefined variable $quota C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 37
ERROR - 2024-09-20 16:32:51 --> Severity: Warning --> Undefined variable $admissions C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 53
ERROR - 2024-09-20 16:32:59 --> Severity: Warning --> Undefined variable $course_options C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 30
ERROR - 2024-09-20 16:32:59 --> Severity: Warning --> Undefined variable $course C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 30
ERROR - 2024-09-20 16:32:59 --> Severity: Warning --> Undefined variable $quota C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 37
ERROR - 2024-09-20 16:32:59 --> Severity: Warning --> Undefined variable $quota C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 37
ERROR - 2024-09-20 16:32:59 --> Severity: Warning --> Undefined variable $admissions C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 53
ERROR - 2024-09-20 16:33:50 --> Severity: error --> Exception: Call to undefined method Admin::courses() C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 141
ERROR - 2024-09-20 13:04:58 --> Severity: error --> Exception: syntax error, unexpected token ",", expecting ")" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 153
ERROR - 2024-09-20 13:04:59 --> Severity: error --> Exception: syntax error, unexpected token ",", expecting ")" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 153
ERROR - 2024-09-20 13:13:41 --> Severity: error --> Exception: syntax error, unexpected token ",", expecting ")" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 153
ERROR - 2024-09-20 13:13:43 --> Severity: error --> Exception: syntax error, unexpected token ",", expecting ")" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 153
ERROR - 2024-09-20 13:13:43 --> Severity: error --> Exception: syntax error, unexpected token ",", expecting ")" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 153
ERROR - 2024-09-20 13:14:24 --> 404 Page Not Found: Admin/department_quota_report
ERROR - 2024-09-20 16:44:36 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 99
ERROR - 2024-09-20 16:55:12 --> Severity: error --> Exception: Call to undefined method Admin::courses() C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 141
ERROR - 2024-09-20 16:57:07 --> Severity: Warning --> Undefined variable $category_claimed C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 32
ERROR - 2024-09-20 16:57:07 --> Severity: Warning --> Undefined variable $admissions C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 49
ERROR - 2024-09-20 16:57:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 177
ERROR - 2024-09-20 16:57:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 177
ERROR - 2024-09-20 16:57:53 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 177
ERROR - 2024-09-20 16:57:53 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 177
ERROR - 2024-09-20 16:57:53 --> Severity: Warning --> Undefined variable $course C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 30
ERROR - 2024-09-20 16:57:53 --> Severity: Warning --> Undefined variable $quota C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 37
ERROR - 2024-09-20 16:57:53 --> Severity: Warning --> Undefined variable $quota C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 37
ERROR - 2024-09-20 16:58:00 --> Severity: Warning --> Undefined variable $quota C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 37
ERROR - 2024-09-20 16:58:00 --> Severity: Warning --> Undefined variable $quota C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 37
ERROR - 2024-09-20 16:58:00 --> Severity: Warning --> Undefined variable $admissions C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 53
ERROR - 2024-09-20 16:58:02 --> Severity: Warning --> Undefined variable $quota C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 37
ERROR - 2024-09-20 16:58:02 --> Severity: Warning --> Undefined variable $quota C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 37
ERROR - 2024-09-20 16:58:02 --> Severity: Warning --> Undefined variable $admissions C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 53
ERROR - 2024-09-20 16:59:40 --> Severity: Warning --> Undefined variable $quota C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 37
ERROR - 2024-09-20 16:59:40 --> Severity: Warning --> Undefined variable $admissions C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 53
ERROR - 2024-09-20 16:59:50 --> Severity: Warning --> Undefined variable $admissions C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 53
ERROR - 2024-09-20 17:03:10 --> Query error: Unknown column 'course' in 'where clause' - Invalid query: SELECT *
FROM `admissions`
WHERE `academic_year` = '2024-2025'
AND `course` = '5'
AND `quota` = 'MGMT'
ORDER BY `admit_date` DESC
ERROR - 2024-09-20 17:04:47 --> Severity: Warning --> Undefined array key "dept_id" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 153
ERROR - 2024-09-20 17:04:55 --> Severity: Warning --> Undefined array key "dept_id" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 153
ERROR - 2024-09-20 17:05:08 --> Severity: Warning --> Undefined array key "dept_id" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 153
ERROR - 2024-09-20 17:05:12 --> Severity: Warning --> Undefined array key "dept_id" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 153
ERROR - 2024-09-20 17:05:17 --> Severity: Warning --> Undefined array key "dept_id" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 153
ERROR - 2024-09-20 17:05:22 --> Severity: Warning --> Undefined array key "dept_id" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 153
ERROR - 2024-09-20 17:05:26 --> Severity: Warning --> Undefined array key "dept_id" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 153
ERROR - 2024-09-20 17:05:32 --> Severity: Warning --> Undefined array key "dept_id" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 153
ERROR - 2024-09-20 17:05:37 --> Severity: Warning --> Undefined array key "dept_id" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 153
ERROR - 2024-09-20 17:06:42 --> Severity: Warning --> Undefined array key "dept_id" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 153
ERROR - 2024-09-20 17:06:46 --> Severity: Warning --> Undefined array key "dept_id" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 153
ERROR - 2024-09-20 17:06:51 --> Severity: Warning --> Undefined array key "dept_id" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 153
ERROR - 2024-09-20 17:06:55 --> Severity: Warning --> Undefined array key "dept_id" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 153
ERROR - 2024-09-20 17:15:12 --> Severity: Warning --> Undefined array key "dept_id" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 153
ERROR - 2024-09-20 17:15:12 --> Severity: Warning --> Undefined variable $academic_year C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 30
ERROR - 2024-09-20 17:15:20 --> Severity: Warning --> Undefined array key "dept_id" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 153
ERROR - 2024-09-20 17:15:20 --> Severity: Warning --> Undefined variable $academic_year C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 30
ERROR - 2024-09-20 17:20:38 --> Severity: Warning --> Undefined array key "dept_id" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 155
ERROR - 2024-09-20 17:22:00 --> Severity: Warning --> Undefined array key "dept_id" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 155
ERROR - 2024-09-20 17:22:10 --> Severity: Warning --> Undefined array key "dept_id" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 155
ERROR - 2024-09-20 17:22:17 --> Severity: Warning --> Undefined variable $academic_year C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 30
ERROR - 2024-09-20 17:22:17 --> Severity: Warning --> Undefined variable $course C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 37
ERROR - 2024-09-20 17:22:17 --> Severity: Warning --> Undefined variable $quota C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 44
ERROR - 2024-09-20 17:22:17 --> Severity: Warning --> Undefined variable $admissions C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 60
ERROR - 2024-09-20 17:22:27 --> Severity: Warning --> Undefined variable $academic_year C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 30
ERROR - 2024-09-20 17:22:27 --> Severity: Warning --> Undefined variable $admissions C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 60
ERROR - 2024-09-20 17:22:33 --> Severity: Warning --> Undefined array key "dept_id" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 155
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:00 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:16 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:16 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:16 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:16 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:16 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:16 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:16 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:16 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:16 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:16 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:16 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:16 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:16 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:27:16 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:19 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:19 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:19 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:19 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:19 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:19 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:19 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:19 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:20 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:21 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:22 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:22 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:22 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:22 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:22 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:22 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:22 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:22 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:22 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:22 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:22 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:22 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:22 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:28:22 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:10 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:11 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:33:12 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 14:03:25 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-20 14:03:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:01 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:03 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:03 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:03 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:03 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:07 --> Severity: Warning --> Undefined variable $academic_year C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 30
ERROR - 2024-09-20 17:36:07 --> Severity: Warning --> Undefined variable $course C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 37
ERROR - 2024-09-20 17:36:07 --> Severity: Warning --> Undefined variable $quota C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 44
ERROR - 2024-09-20 17:36:07 --> Severity: Warning --> Undefined variable $admissions C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 60
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:16 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:16 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:16 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:16 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:16 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:16 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:16 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:16 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:16 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:16 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:16 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:16 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:16 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:16 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:16 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:16 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:16 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:16 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:16 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:16 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:16 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:16 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:16 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:36:16 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:55 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:55 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:55 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:55 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:55 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:55 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:55 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:55 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:55 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:55 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:55 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:55 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:55 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:55 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:55 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:55 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:55 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:55 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:55 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:55 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:55 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:55 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:55 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:55 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:55 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:55 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:55 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:37:55 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:38:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:40:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:13 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:13 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:13 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:13 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:13 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:13 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:13 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:13 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:13 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:13 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:13 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:13 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:13 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:13 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:13 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:13 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:13 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:13 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:13 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:13 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:14 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:15 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:41:15 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 14:11:31 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-20 14:11:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:26 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:27 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:27 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:27 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:27 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:27 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:27 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:27 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:27 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:27 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:27 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:27 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:27 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:27 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:27 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:27 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:27 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:27 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:27 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:27 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:27 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:27 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:27 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:27 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:27 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:27 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:27 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:27 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:27 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:57 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:42:58 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:17 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:17 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:17 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:17 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:17 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:17 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:17 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:17 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:17 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:17 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:18 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:19 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:19 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:19 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:43:19 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:02 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:02 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:03 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:04 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:04 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:04 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:04 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:04 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:04 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:04 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:04 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:04 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:04 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:04 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:04 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:04 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:04 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:43 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:43 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:43 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:43 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:43 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:43 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:43 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:43 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:43 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:43 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:43 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:43 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:43 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:43 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:43 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:43 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:43 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:43 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:44 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:44:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:40 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:41 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:42 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:42 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:42 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:42 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:42 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:42 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:42 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:42 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:45:50 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-20 17:45:50 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-20 17:45:50 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-20 17:47:35 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-20 17:47:35 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-20 17:47:35 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-20 17:47:40 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-20 17:47:40 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-20 17:47:40 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-20 17:47:43 --> Severity: Warning --> Undefined variable $academic_year C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 24
ERROR - 2024-09-20 17:47:43 --> Severity: Warning --> Undefined variable $course C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 31
ERROR - 2024-09-20 17:47:43 --> Severity: Warning --> Undefined variable $quota C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 38
ERROR - 2024-09-20 17:47:43 --> Severity: Warning --> Undefined variable $admissions C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 52
ERROR - 2024-09-20 17:47:56 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:47:56 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:47:56 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:47:56 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:47:56 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:47:56 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:47:56 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:47:56 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:47:56 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:47:56 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:47:56 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:47:56 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:47:56 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:47:56 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:47:56 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:47:56 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:47:56 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:47:56 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:47:56 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:47:56 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:47:56 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:47:56 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:47:56 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:47:56 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:47:56 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:47:56 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:47:56 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:47:56 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:50:11 --> Severity: Warning --> Undefined variable $academic_year C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 24
ERROR - 2024-09-20 17:50:11 --> Severity: Warning --> Undefined variable $course C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 31
ERROR - 2024-09-20 17:50:11 --> Severity: Warning --> Undefined variable $quota C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 38
ERROR - 2024-09-20 17:50:11 --> Severity: Warning --> Undefined variable $admissions C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 52
ERROR - 2024-09-20 17:50:49 --> Severity: Warning --> Undefined variable $academic_year C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 24
ERROR - 2024-09-20 17:50:49 --> Severity: Warning --> Undefined variable $course C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 31
ERROR - 2024-09-20 17:50:49 --> Severity: Warning --> Undefined variable $quota C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 38
ERROR - 2024-09-20 17:50:49 --> Severity: Warning --> Undefined variable $admissions C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 52
ERROR - 2024-09-20 17:52:57 --> Severity: error --> Exception: Unsupported operand types: array + string C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 140
ERROR - 2024-09-20 17:53:38 --> Severity: Warning --> Undefined variable $academic_year C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 24
ERROR - 2024-09-20 17:53:38 --> Severity: Warning --> Undefined variable $course C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 31
ERROR - 2024-09-20 17:53:38 --> Severity: Warning --> Undefined variable $quota C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 38
ERROR - 2024-09-20 17:53:38 --> Severity: Warning --> Undefined variable $admissions C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 52
ERROR - 2024-09-20 17:53:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:45 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:45 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:46 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:46 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:46 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:46 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:46 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:46 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:46 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:46 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:46 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:46 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:46 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:46 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:46 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:46 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:46 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:46 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:46 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:46 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:46 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:46 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:46 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:46 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:46 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:53:46 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:32 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:32 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:32 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:32 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:32 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:32 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:32 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:32 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:32 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:32 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:33 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:33 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:33 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:33 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:33 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:33 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:33 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:33 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:33 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:33 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:33 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:33 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:33 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:33 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:33 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:33 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:33 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:33 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:33 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:33 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:33 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:33 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:33 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:33 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:34 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:34 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:34 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:34 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:34 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:34 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:34 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:34 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:34 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:34 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:54 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:55 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:55 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:55 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:55 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:55 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:55 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:55 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:55 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:55 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:55 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:55 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:55 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:55 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:55 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:55 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:55 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:55 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:55 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:55 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:54:55 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 17:55:40 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-20 17:55:40 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-20 17:55:40 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-20 17:57:16 --> Severity: Warning --> Undefined variable $academic_year C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 24
ERROR - 2024-09-20 17:57:16 --> Severity: Warning --> Undefined variable $course C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 31
ERROR - 2024-09-20 17:57:16 --> Severity: Warning --> Undefined variable $quota C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 38
ERROR - 2024-09-20 17:57:16 --> Severity: Warning --> Undefined variable $admissions C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 52
ERROR - 2024-09-20 17:57:40 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 99
ERROR - 2024-09-20 17:58:22 --> Severity: Warning --> Undefined variable $academic_year C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 24
ERROR - 2024-09-20 17:58:22 --> Severity: Warning --> Undefined variable $course C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 31
ERROR - 2024-09-20 17:58:22 --> Severity: Warning --> Undefined variable $quota C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 38
ERROR - 2024-09-20 17:58:22 --> Severity: Warning --> Undefined variable $admissions C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 52
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:28 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:29 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:30 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:30 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:30 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:30 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:30 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:30 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:58 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:58 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:58 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:58 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:58 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:58 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:58 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:58 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:58 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:58 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:58 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:02:58 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:23 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:23 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:23 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:23 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:23 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:23 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:23 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:23 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:03:39 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 18:10:38 --> Severity: Warning --> Undefined variable $academic_year C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 24
ERROR - 2024-09-20 18:10:38 --> Severity: Warning --> Undefined variable $course C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 31
ERROR - 2024-09-20 18:10:38 --> Severity: Warning --> Undefined variable $quota C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 38
ERROR - 2024-09-20 18:10:38 --> Severity: Warning --> Undefined variable $admissions C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 52
ERROR - 2024-09-20 18:10:40 --> Severity: Warning --> Undefined variable $academic_year C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 24
ERROR - 2024-09-20 18:10:40 --> Severity: Warning --> Undefined variable $admissions C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 52
ERROR - 2024-09-20 18:13:25 --> Severity: Warning --> Undefined variable $academic_year C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 24
ERROR - 2024-09-20 18:13:25 --> Severity: Warning --> Undefined variable $course C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 33
ERROR - 2024-09-20 18:13:25 --> Severity: Warning --> Undefined variable $quota C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 40
ERROR - 2024-09-20 18:13:25 --> Severity: Warning --> Undefined variable $admissions C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 54
ERROR - 2024-09-20 18:15:53 --> Severity: Warning --> Undefined variable $academic_year C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 24
ERROR - 2024-09-20 18:15:53 --> Severity: Warning --> Undefined variable $course C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 33
ERROR - 2024-09-20 18:15:53 --> Severity: Warning --> Undefined variable $quota C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 40
ERROR - 2024-09-20 18:15:53 --> Severity: Warning --> Undefined variable $admissions C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 54
ERROR - 2024-09-20 18:22:54 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-20 18:22:54 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-20 18:22:54 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-20 18:26:44 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-20 18:33:03 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-20 18:33:57 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-20 18:39:50 --> Severity: Warning --> Undefined property: stdClass::$permanent_address C:\xampp\htdocs\mce_campus\application\views\student\profile.php 253
ERROR - 2024-09-20 18:40:43 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-20 18:40:43 --> Severity: Warning --> Undefined variable $father_name C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 170
ERROR - 2024-09-20 18:44:59 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-20 18:45:01 --> Severity: Warning --> Undefined variable $father_name C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 170
ERROR - 2024-09-20 18:45:01 --> Severity: Warning --> Undefined variable $current_address C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 179
ERROR - 2024-09-20 18:45:01 --> Severity: Warning --> Undefined variable $present_address C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 187
ERROR - 2024-09-20 18:47:27 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-20 18:47:28 --> Severity: Warning --> Undefined variable $father_name C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 170
ERROR - 2024-09-20 18:47:36 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-20 18:47:56 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-20 18:47:56 --> Severity: Warning --> Undefined variable $father_name C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 170
ERROR - 2024-09-20 18:48:00 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-20 15:30:36 --> 404 Page Not Found: Student/parent_details
ERROR - 2024-09-20 15:31:12 --> 404 Page Not Found: Student/parent_details
ERROR - 2024-09-20 19:03:16 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 200
ERROR - 2024-09-20 19:03:16 --> Severity: Warning --> Undefined variable $student_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-20 19:07:07 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 200
ERROR - 2024-09-20 19:07:07 --> Severity: Warning --> Undefined variable $student_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-20 19:07:07 --> Severity: Warning --> Undefined variable $encryptId C:\xampp\htdocs\mce_campus\application\views\student\parent_details.php 150
ERROR - 2024-09-20 15:37:13 --> 404 Page Not Found: Admin/admissionDetails
ERROR - 2024-09-20 19:07:16 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 200
ERROR - 2024-09-20 19:07:16 --> Severity: Warning --> Undefined variable $student_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-20 19:07:16 --> Severity: Warning --> Undefined variable $encryptId C:\xampp\htdocs\mce_campus\application\views\student\parent_details.php 150
ERROR - 2024-09-20 19:07:34 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 200
ERROR - 2024-09-20 19:07:34 --> Severity: Warning --> Undefined variable $student_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-20 19:07:34 --> Severity: Warning --> Undefined variable $encryptId C:\xampp\htdocs\mce_campus\application\views\student\parent_details.php 150
ERROR - 2024-09-20 15:37:41 --> 404 Page Not Found: Admin/profile
ERROR - 2024-09-20 19:07:44 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 200
ERROR - 2024-09-20 19:07:44 --> Severity: Warning --> Undefined variable $student_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-20 19:07:44 --> Severity: Warning --> Undefined variable $encryptId C:\xampp\htdocs\mce_campus\application\views\student\parent_details.php 150
ERROR - 2024-09-20 19:08:06 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 200
ERROR - 2024-09-20 19:08:06 --> Severity: Warning --> Undefined variable $student_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-20 19:08:06 --> Severity: Warning --> Undefined variable $encryptId C:\xampp\htdocs\mce_campus\application\views\student\parent_details.php 150
ERROR - 2024-09-20 15:38:11 --> 404 Page Not Found: Student/parent_details
ERROR - 2024-09-20 19:08:16 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 200
ERROR - 2024-09-20 19:08:16 --> Severity: Warning --> Undefined variable $student_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-20 19:08:16 --> Severity: Warning --> Undefined variable $encryptId C:\xampp\htdocs\mce_campus\application\views\student\parent_details.php 150
ERROR - 2024-09-20 19:09:24 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 200
ERROR - 2024-09-20 19:09:24 --> Severity: Warning --> Undefined variable $student_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-20 15:39:27 --> 404 Page Not Found: Student/parent_details
ERROR - 2024-09-20 19:09:34 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 200
ERROR - 2024-09-20 19:09:34 --> Severity: Warning --> Undefined variable $student_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-20 19:10:43 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 200
ERROR - 2024-09-20 19:10:43 --> Severity: Warning --> Undefined variable $student_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-20 15:40:50 --> 404 Page Not Found: Student/parent_details
ERROR - 2024-09-20 19:12:08 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 200
ERROR - 2024-09-20 19:12:08 --> Severity: Warning --> Undefined variable $student_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-20 19:12:11 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 200
ERROR - 2024-09-20 19:12:11 --> Severity: Warning --> Undefined variable $student_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-20 15:42:18 --> 404 Page Not Found: Student/parent_details
ERROR - 2024-09-20 19:12:20 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 200
ERROR - 2024-09-20 19:12:20 --> Severity: Warning --> Undefined variable $student_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-20 19:12:31 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 200
ERROR - 2024-09-20 19:12:31 --> Severity: Warning --> Undefined variable $student_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-20 19:12:42 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-20 19:12:42 --> Severity: Warning --> Undefined variable $father_name C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 170
ERROR - 2024-09-20 19:12:45 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-20 19:12:48 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 200
ERROR - 2024-09-20 19:12:48 --> Severity: Warning --> Undefined variable $student_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-20 19:13:42 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 200
ERROR - 2024-09-20 19:13:42 --> Severity: Warning --> Undefined variable $student_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-20 19:13:45 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 200
ERROR - 2024-09-20 19:13:45 --> Severity: Warning --> Undefined variable $student_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-20 15:43:49 --> 404 Page Not Found: Student/parent_details
ERROR - 2024-09-20 19:13:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 200
ERROR - 2024-09-20 19:13:53 --> Severity: Warning --> Undefined variable $student_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-20 15:45:02 --> 404 Page Not Found: Student/parent_details
ERROR - 2024-09-20 19:15:06 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 200
ERROR - 2024-09-20 19:15:06 --> Severity: Warning --> Undefined variable $student_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-20 19:17:02 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-20 19:17:02 --> Severity: Warning --> Undefined variable $father_name C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 170
ERROR - 2024-09-20 19:17:11 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-20 19:17:15 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-20 19:17:15 --> Severity: Warning --> Undefined variable $father_name C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 170
ERROR - 2024-09-20 19:17:18 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-20 19:17:50 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-20 19:17:50 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-20 19:17:50 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-20 19:17:55 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-20 19:17:55 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-20 19:17:55 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-20 19:17:57 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 99
ERROR - 2024-09-20 19:18:22 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-20 19:18:22 --> Severity: Warning --> Undefined variable $father_name C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 170
ERROR - 2024-09-20 19:19:17 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-20 19:19:17 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-20 19:19:17 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-20 19:19:20 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-20 19:19:20 --> Severity: Warning --> Undefined variable $father_name C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 170
ERROR - 2024-09-20 19:20:01 --> Severity: Warning --> Undefined variable $academic_year C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 24
ERROR - 2024-09-20 19:20:01 --> Severity: Warning --> Undefined variable $course C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 33
ERROR - 2024-09-20 19:20:01 --> Severity: Warning --> Undefined variable $quota C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 40
ERROR - 2024-09-20 19:20:01 --> Severity: Warning --> Undefined variable $admissions C:\xampp\htdocs\mce_campus\application\views\admin\department_quota_report.php 54
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined variable $course_id C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:08 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 181
ERROR - 2024-09-20 19:20:17 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-20 19:20:17 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-20 19:20:17 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-20 19:23:09 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-20 19:23:09 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-20 19:23:09 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-20 19:23:46 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-20 19:23:46 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-20 19:23:46 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
