<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-09-22 11:58:09 --> Severity: Warning --> Undefined property: stdClass::$flow C:\xampp\htdocs\mce_campus\application\controllers\Student.php 47
ERROR - 2024-09-22 08:37:02 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 08:40:43 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 08:44:15 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 08:44:19 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 08:44:38 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 08:49:30 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 08:50:48 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 08:54:59 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 08:57:31 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 08:58:32 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 08:58:34 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 12:43:33 --> Query error: Unknown column '4MC23CB001' in 'where clause' - Invalid query: SELECT *
FROM `students`
WHERE `4MC23CB001` = 'usn'
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 23
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 23
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 37
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 37
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 51
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 51
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 65
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 65
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 79
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 79
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 107
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 107
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 121
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 121
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 135
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 135
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 149
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 149
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 163
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 163
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 180
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 180
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 194
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 194
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 208
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 208
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 222
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 222
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 236
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 236
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 253
ERROR - 2024-09-22 12:44:15 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 253
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 23
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 23
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 37
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 37
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 51
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 51
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 65
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 65
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 79
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 79
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 107
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 107
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 121
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 121
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 135
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 135
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 149
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 149
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 163
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 163
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 180
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 180
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 194
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 194
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 208
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 208
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 222
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 222
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 236
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 236
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 253
ERROR - 2024-09-22 12:44:30 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 253
ERROR - 2024-09-22 09:14:34 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 23
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 23
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 37
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 37
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 51
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 51
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 65
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 65
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 79
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 79
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 107
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 107
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 121
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 121
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 135
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 135
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 149
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 149
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 163
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 163
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 180
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 180
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 194
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 194
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 208
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 208
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 222
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 222
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 236
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 236
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 253
ERROR - 2024-09-22 12:47:18 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 253
ERROR - 2024-09-22 09:17:18 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 23
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 23
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 37
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 37
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 51
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 51
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 65
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 65
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 79
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 79
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 107
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 107
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 121
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 121
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 135
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 135
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 149
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 149
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 163
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 163
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 180
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 180
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 194
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 194
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 208
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 208
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 222
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 222
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 236
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 236
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 253
ERROR - 2024-09-22 12:48:18 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 253
ERROR - 2024-09-22 09:18:19 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 33
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 33
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 45
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 45
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 57
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 57
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 69
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 69
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 81
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 81
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 109
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 109
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 121
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 121
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 133
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 133
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 145
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 145
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 157
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 157
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 172
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 172
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 184
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 184
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 196
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 196
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 208
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 208
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 220
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 220
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 235
ERROR - 2024-09-22 12:51:02 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 235
ERROR - 2024-09-22 09:21:03 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 33
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 33
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 45
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 45
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 57
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 57
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 69
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 69
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 81
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 81
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 109
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 109
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 121
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 121
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 133
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 133
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 145
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 145
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 157
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 157
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 172
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 172
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 184
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 184
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 196
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 196
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 208
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 208
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 220
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 220
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 235
ERROR - 2024-09-22 12:53:37 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 235
ERROR - 2024-09-22 09:23:37 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 33
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 33
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 45
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 45
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 57
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 57
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 69
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 69
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 81
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 81
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 109
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 109
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 121
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 121
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 133
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 133
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 145
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 145
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 157
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 157
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 172
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 172
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 184
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 184
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 196
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 196
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 208
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 208
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 220
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 220
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 235
ERROR - 2024-09-22 12:53:49 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 235
ERROR - 2024-09-22 09:23:50 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 33
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 33
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 45
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 45
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 57
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 57
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 69
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 69
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 81
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 81
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 109
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 109
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 121
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 121
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 133
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 133
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 145
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 145
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 157
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 157
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 172
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 172
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 184
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 184
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 196
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 196
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 208
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 208
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 220
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 220
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 235
ERROR - 2024-09-22 12:53:52 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 235
ERROR - 2024-09-22 09:23:52 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 13:08:59 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 16:39:20 --> Severity: Warning --> Undefined property: stdClass::$flow C:\xampp\htdocs\mce_campus\application\controllers\Student.php 47
ERROR - 2024-09-22 13:09:20 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 33
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 33
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 45
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 45
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 57
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 57
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 69
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 69
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 81
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 81
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 109
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 109
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 121
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 121
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 133
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 133
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 145
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 145
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 157
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 157
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 172
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 172
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 184
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 184
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 196
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 196
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 208
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 208
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 220
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 220
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 235
ERROR - 2024-09-22 16:39:24 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 235
ERROR - 2024-09-22 13:09:24 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 51
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 51
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 63
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 63
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 75
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 75
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 87
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 87
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 99
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 99
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 127
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 127
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 139
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 139
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 151
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 151
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 163
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 163
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 175
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 175
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 190
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 190
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 202
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 202
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 214
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 214
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 226
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 226
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 238
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 238
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 253
ERROR - 2024-09-22 16:44:24 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 253
ERROR - 2024-09-22 13:14:24 --> 404 Page Not Found: Student/assets
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 51
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 51
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 63
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 63
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 75
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 75
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 87
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 87
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 99
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 99
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 127
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 127
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 139
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 139
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 151
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 151
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 163
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 163
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 175
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 175
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 190
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 190
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 202
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 202
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 214
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 214
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 226
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 226
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 238
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 238
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 253
ERROR - 2024-09-22 16:46:03 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 253
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 51
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 51
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 63
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 63
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 75
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 75
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 87
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 87
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 99
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 99
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 127
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 127
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 139
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 139
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 151
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 151
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 163
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 163
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 175
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 175
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 190
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 190
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 202
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 202
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 214
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 214
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 226
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 226
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 238
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 238
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 253
ERROR - 2024-09-22 16:46:39 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 253
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 52
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 52
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 64
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 64
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 76
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 76
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 88
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 88
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 100
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 100
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 128
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 128
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 140
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 140
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 152
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 152
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 164
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 164
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 176
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 176
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 191
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 191
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 203
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 203
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 215
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 215
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 227
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 227
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 239
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 239
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 254
ERROR - 2024-09-22 16:46:46 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 254
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 53
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 53
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 65
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 65
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 77
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 77
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 89
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 89
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 101
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 101
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 129
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 129
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 141
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 141
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 153
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 153
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 165
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 165
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 177
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 177
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 192
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 192
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 204
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 204
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 216
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 216
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 228
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 228
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 240
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 240
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 255
ERROR - 2024-09-22 16:46:53 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 255
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 51
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 51
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 63
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 63
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 75
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 75
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 87
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 87
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 99
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 99
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 127
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 127
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 139
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 139
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 151
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 151
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 163
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 163
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 175
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 175
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 190
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 190
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 202
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 202
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 214
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 214
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 226
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 226
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 238
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 238
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 253
ERROR - 2024-09-22 16:47:06 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 253
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 51
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 51
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 63
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 63
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 75
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 75
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 87
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 87
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 99
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 99
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 127
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 127
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 139
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 139
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 151
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 151
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 163
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 163
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 175
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 175
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 190
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 190
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 202
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 202
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 214
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 214
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 226
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 226
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 238
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 238
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 253
ERROR - 2024-09-22 16:47:18 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 253
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 51
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 51
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 63
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 63
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 75
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 75
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 87
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 87
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 99
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 99
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 127
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 127
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 139
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 139
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 151
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 151
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 163
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 163
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 175
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 175
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 190
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 190
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 202
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 202
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 214
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 214
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 226
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 226
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 238
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 238
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 253
ERROR - 2024-09-22 16:47:23 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 253
ERROR - 2024-09-22 13:17:23 --> 404 Page Not Found: Student/assets
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 51
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 51
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 63
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 63
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 75
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 75
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 87
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 87
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 99
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 99
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 127
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 127
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 139
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 139
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 151
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 151
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 163
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 163
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 175
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 175
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 190
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 190
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 202
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 202
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 214
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 214
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 226
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 226
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 238
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 238
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 253
ERROR - 2024-09-22 16:47:50 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 253
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 51
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 51
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 63
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 63
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 75
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 75
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 87
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 87
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 99
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 99
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 127
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 127
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 139
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 139
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 151
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 151
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 163
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 163
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 175
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 175
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 190
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 190
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 202
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 202
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 214
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 214
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 226
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 226
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 238
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 238
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 253
ERROR - 2024-09-22 16:48:05 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 253
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 86
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 86
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 98
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 98
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 110
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 110
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 122
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 122
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 134
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 134
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 162
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 162
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 174
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 174
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 186
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 186
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 198
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 198
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 210
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 210
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 225
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 225
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 237
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 237
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 249
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 249
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 261
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 261
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 273
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 273
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 288
ERROR - 2024-09-22 16:48:50 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 288
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 67
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 67
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 79
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 79
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 91
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 91
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 103
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 103
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 115
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 115
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 143
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 143
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 155
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 155
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 167
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 167
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 179
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 179
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 191
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 191
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 206
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 206
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 218
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 218
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 230
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 230
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 242
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 242
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 254
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 254
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 269
ERROR - 2024-09-22 16:50:33 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 269
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 67
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 67
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 79
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 79
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 91
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 91
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 103
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 103
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 115
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 115
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 143
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 143
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 155
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 155
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 167
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 167
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 179
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 179
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 191
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 191
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 206
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 206
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 218
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 218
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 230
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 230
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 242
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 242
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 254
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 254
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 269
ERROR - 2024-09-22 16:50:48 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 269
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 67
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 67
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 79
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 79
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 91
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 91
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 103
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 103
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 115
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 115
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 143
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 143
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 155
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 155
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 167
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 167
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 179
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 179
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 191
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 191
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 206
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 206
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 218
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 218
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 230
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 230
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 242
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 242
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 254
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 254
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 269
ERROR - 2024-09-22 16:51:25 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 269
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 16
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 16
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 73
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 73
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 85
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 85
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 97
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 97
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 109
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 109
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 121
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 121
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 149
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 149
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 161
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 161
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 173
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 173
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 185
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 185
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 197
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 197
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 212
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 212
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 224
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 224
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 236
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 236
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 248
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 248
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 260
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 260
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 275
ERROR - 2024-09-22 16:51:49 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 275
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 73
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 73
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 85
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 85
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 97
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 97
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 109
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 109
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 121
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 121
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 149
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 149
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 161
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 161
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 173
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 173
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 185
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 185
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 197
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 197
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 212
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 212
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 224
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 224
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 236
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 236
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 248
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 248
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 260
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 260
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 275
ERROR - 2024-09-22 16:52:02 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 275
ERROR - 2024-09-22 13:22:29 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 73
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 73
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 85
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 85
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 97
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 97
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 109
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 109
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 121
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 121
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 149
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 149
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 161
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 161
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 173
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 173
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 185
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 185
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 197
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 197
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 212
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 212
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 224
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 224
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 236
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 236
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 248
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 248
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 260
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 260
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 275
ERROR - 2024-09-22 16:56:31 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 275
ERROR - 2024-09-22 13:26:32 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 73
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 73
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 85
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 85
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 97
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 97
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 109
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 109
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 121
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 121
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 149
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 149
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 161
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 161
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 173
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 173
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 185
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 185
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 197
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 197
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 212
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 212
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 224
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 224
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 236
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 236
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 248
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 248
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 260
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 260
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 275
ERROR - 2024-09-22 16:56:35 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 275
ERROR - 2024-09-22 13:26:35 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 73
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 73
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 85
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 85
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 97
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 97
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 109
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 109
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 121
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 121
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 149
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 149
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 161
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 161
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 173
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 173
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 185
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 185
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 197
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 197
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 212
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 212
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 224
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 224
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 236
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 236
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 248
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 248
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 260
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 260
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 275
ERROR - 2024-09-22 16:57:07 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 275
ERROR - 2024-09-22 13:27:07 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 71
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 71
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 83
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 83
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 95
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 95
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 107
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 107
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 119
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 119
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 147
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 147
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 159
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 159
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 171
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 171
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 183
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 183
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 195
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 195
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 210
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 210
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 222
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 222
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 234
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 234
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 246
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 246
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 258
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 258
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 273
ERROR - 2024-09-22 17:01:17 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 273
ERROR - 2024-09-22 13:31:17 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 71
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 71
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 83
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 83
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 95
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 95
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 107
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 107
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 119
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 119
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 147
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 147
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 159
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 159
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 171
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 171
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 183
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 183
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 195
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 195
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 210
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 210
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 222
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 222
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 234
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 234
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 246
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 246
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 258
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 258
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 273
ERROR - 2024-09-22 17:02:33 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 273
ERROR - 2024-09-22 13:32:33 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 71
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 71
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 83
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 83
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 95
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 95
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 107
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 107
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 119
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 119
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 147
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 147
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 159
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 159
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 171
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 171
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 183
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 183
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 195
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 195
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 210
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 210
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 222
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 222
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 234
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 234
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 246
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 246
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 258
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 258
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 273
ERROR - 2024-09-22 17:02:59 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 273
ERROR - 2024-09-22 13:32:59 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 131
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 131
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 143
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 143
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 155
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 155
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 167
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 167
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 179
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 179
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 207
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 207
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 219
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 219
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 231
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 231
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 243
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 243
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 255
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 255
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 270
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 270
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 282
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 282
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 294
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 294
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 306
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 306
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 318
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 318
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 333
ERROR - 2024-09-22 17:08:03 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 333
ERROR - 2024-09-22 13:38:04 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Undefined property: stdClass::$fathert_number C:\xampp\htdocs\mce_campus\application\views\student\profile.php 53
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 233
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 233
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 245
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 245
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 257
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 257
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 269
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 269
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 281
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 281
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 309
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 309
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 321
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 321
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 333
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 333
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 345
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 345
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 357
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 357
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 372
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 372
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 384
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 384
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 396
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 396
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 408
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 408
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 420
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 420
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 435
ERROR - 2024-09-22 17:17:59 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 435
ERROR - 2024-09-22 13:48:00 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Undefined property: stdClass::$fathert_number C:\xampp\htdocs\mce_campus\application\views\student\profile.php 53
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 233
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 233
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 245
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 245
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 257
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 257
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 269
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 269
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 281
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 281
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 309
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 309
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 321
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 321
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 333
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 333
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 345
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 345
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 357
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 357
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 372
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 372
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 384
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 384
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 396
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 396
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 408
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 408
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 420
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 420
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 435
ERROR - 2024-09-22 17:18:16 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 435
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 233
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 233
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 245
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 245
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 257
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 257
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 269
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 269
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 281
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 281
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 309
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 309
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 321
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 321
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 333
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 333
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 345
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 345
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 357
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 357
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 372
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 372
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 384
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 384
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 396
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 396
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 408
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 408
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 420
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 420
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 435
ERROR - 2024-09-22 17:18:47 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 435
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 258
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 258
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 270
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 270
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 282
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 282
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 294
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 294
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 306
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 306
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 334
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 334
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 346
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 346
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 358
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 358
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 370
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 370
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 382
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 382
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 397
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 397
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 409
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 409
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 421
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 421
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 433
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 433
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 445
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 445
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 460
ERROR - 2024-09-22 17:21:05 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 460
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 258
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 258
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 270
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 270
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 282
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 282
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 294
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 294
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 306
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 306
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 334
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 334
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 346
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 346
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 358
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 358
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 370
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 370
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 382
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 382
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 397
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 397
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 409
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 409
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 421
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 421
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 433
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 433
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 445
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 445
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 460
ERROR - 2024-09-22 17:21:49 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 460
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 258
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 258
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 270
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 270
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 282
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 282
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 294
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 294
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 306
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 306
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 334
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 334
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 346
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 346
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 358
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 358
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 370
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 370
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 382
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 382
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 397
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 397
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 409
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 409
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 421
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 421
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 433
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 433
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 445
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 445
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 460
ERROR - 2024-09-22 17:21:53 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 460
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 258
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 258
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 270
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 270
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 282
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 282
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 294
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 294
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 306
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 306
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 334
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 334
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 346
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 346
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 358
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 358
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 370
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 370
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 382
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 382
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 397
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 397
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 409
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 409
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 421
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 421
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 433
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 433
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 445
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 445
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 460
ERROR - 2024-09-22 17:23:21 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 460
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 298
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 298
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 310
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 310
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 322
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 322
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 334
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 334
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 346
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 346
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 374
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 374
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 386
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 386
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 398
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 398
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 410
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 410
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 422
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 422
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 437
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 437
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 449
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 449
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 461
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 461
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 473
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 473
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 485
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 485
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 500
ERROR - 2024-09-22 17:24:55 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 500
ERROR - 2024-09-22 17:25:15 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 102
ERROR - 2024-09-22 17:25:16 --> Severity: Warning --> Undefined variable $father_name C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 170
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 298
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 298
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 310
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Attempt to read property "mobile" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 310
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 322
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 322
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 334
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Attempt to read property "aadhaar" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 334
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 346
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Attempt to read property "country_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 346
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 374
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Attempt to read property "date_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 374
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 386
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Attempt to read property "gender" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 386
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 398
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Attempt to read property "sports" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 398
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 410
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Attempt to read property "blood_group" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 410
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 422
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Attempt to read property "place_of_birth" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 422
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 437
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Attempt to read property "nationality" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 437
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 449
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Attempt to read property "religion" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 449
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 461
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Attempt to read property "mother_tongue" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 461
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 473
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 473
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 485
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Attempt to read property "current_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 485
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Undefined variable $admissionDetails C:\xampp\htdocs\mce_campus\application\views\student\profile.php 500
ERROR - 2024-09-22 17:25:26 --> Severity: Warning --> Attempt to read property "present_address" on null C:\xampp\htdocs\mce_campus\application\views\student\profile.php 500
ERROR - 2024-09-22 14:08:54 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:09:34 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:10:11 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:13:16 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:13:39 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:14:02 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:14:05 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:15:28 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:16:32 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:16:35 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:17:16 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:19:13 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:19:21 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:19:27 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:20:26 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:20:30 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:20:34 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:20:35 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 17:50:36 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-22 17:50:36 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-22 17:50:36 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-22 14:20:36 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:20:39 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:20:45 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:20:46 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 17:50:48 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-22 17:50:48 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-22 17:50:48 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-22 14:20:48 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:20:55 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:21:07 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:21:24 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:22:18 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:22:35 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:23:20 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:23:26 --> 404 Page Not Found: Student/fees
ERROR - 2024-09-22 14:23:46 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 17:53:49 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-22 17:53:49 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-22 17:53:49 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-22 14:23:49 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 17:54:08 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-22 17:54:08 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-22 17:54:08 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-22 17:58:49 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-22 17:58:49 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-22 17:58:49 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 37
ERROR - 2024-09-22 18:00:41 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 28
ERROR - 2024-09-22 18:00:41 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 35
ERROR - 2024-09-22 18:00:41 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 42
ERROR - 2024-09-22 14:30:42 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 18:01:09 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:01:09 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:01:09 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:01:11 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:01:11 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:01:11 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:01:19 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:01:19 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:01:19 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:01:29 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:01:29 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:01:29 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:01:45 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:01:45 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:01:45 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:01:54 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:01:54 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:01:54 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:02:27 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:02:27 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:02:27 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:02:30 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:02:30 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:02:30 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:02:45 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:02:45 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:02:45 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:02:48 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:02:48 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:02:48 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:03:27 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:03:27 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:03:27 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 14:33:29 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 18:03:33 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:03:33 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:03:33 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 14:33:33 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 18:03:50 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:03:50 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:03:50 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 14:33:51 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 18:03:54 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:03:54 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:03:54 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 14:33:54 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 18:04:08 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:04:08 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:04:08 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 14:34:08 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 18:04:22 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:04:22 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:04:22 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 14:34:22 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 18:04:27 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:04:27 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:04:27 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:04:59 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:04:59 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:04:59 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:05:09 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:05:09 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:05:09 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:05:27 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:05:27 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:05:27 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:06:29 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:06:29 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:06:29 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:06:57 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:06:57 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:06:57 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:07:03 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:07:03 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:07:03 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:07:14 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:07:14 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:07:14 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:07:26 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:07:26 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:07:26 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:07:30 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:07:30 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:07:30 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:09:49 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:09:49 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:09:49 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:10:19 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:10:19 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:10:19 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:10:33 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:10:33 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:10:33 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:10:42 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:10:42 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:10:42 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:10:53 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:10:53 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:10:53 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:11:45 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:11:45 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:11:45 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:11:53 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:11:53 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:11:53 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:12:07 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:12:07 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:12:07 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:12:14 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:12:14 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:12:14 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:12:22 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:12:22 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:12:22 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 14:42:24 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 18:13:38 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:13:38 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:13:38 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:13:41 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 29
ERROR - 2024-09-22 18:13:41 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 36
ERROR - 2024-09-22 18:13:41 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 43
ERROR - 2024-09-22 18:14:14 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 34
ERROR - 2024-09-22 18:14:14 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 41
ERROR - 2024-09-22 18:14:14 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 48
ERROR - 2024-09-22 18:14:23 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 34
ERROR - 2024-09-22 18:14:23 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 41
ERROR - 2024-09-22 18:14:23 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 48
ERROR - 2024-09-22 18:14:29 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 34
ERROR - 2024-09-22 18:14:29 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 41
ERROR - 2024-09-22 18:14:29 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 48
ERROR - 2024-09-22 18:14:49 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 34
ERROR - 2024-09-22 18:14:49 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 41
ERROR - 2024-09-22 18:14:49 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 48
ERROR - 2024-09-22 18:15:17 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 34
ERROR - 2024-09-22 18:15:17 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 41
ERROR - 2024-09-22 18:15:17 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 48
ERROR - 2024-09-22 18:15:19 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 34
ERROR - 2024-09-22 18:15:19 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 41
ERROR - 2024-09-22 18:15:19 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 48
ERROR - 2024-09-22 18:15:29 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 34
ERROR - 2024-09-22 18:15:29 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 41
ERROR - 2024-09-22 18:15:29 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 48
ERROR - 2024-09-22 18:16:16 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 34
ERROR - 2024-09-22 18:16:16 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 41
ERROR - 2024-09-22 18:16:16 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 48
ERROR - 2024-09-22 18:17:05 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 34
ERROR - 2024-09-22 18:17:05 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 41
ERROR - 2024-09-22 18:17:05 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 48
ERROR - 2024-09-22 18:17:09 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 34
ERROR - 2024-09-22 18:17:09 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 41
ERROR - 2024-09-22 18:17:09 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 48
ERROR - 2024-09-22 18:17:18 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 34
ERROR - 2024-09-22 18:17:18 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 41
ERROR - 2024-09-22 18:17:18 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 48
ERROR - 2024-09-22 14:47:26 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 18:17:28 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 34
ERROR - 2024-09-22 18:17:28 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 41
ERROR - 2024-09-22 18:17:28 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 48
ERROR - 2024-09-22 14:47:29 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 18:17:55 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 34
ERROR - 2024-09-22 18:17:55 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 41
ERROR - 2024-09-22 18:17:55 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 48
ERROR - 2024-09-22 14:47:55 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 18:18:10 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 34
ERROR - 2024-09-22 18:18:10 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 41
ERROR - 2024-09-22 18:18:10 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 48
ERROR - 2024-09-22 18:18:18 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 34
ERROR - 2024-09-22 18:18:18 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 41
ERROR - 2024-09-22 18:18:18 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 48
ERROR - 2024-09-22 18:18:37 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:18:37 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:18:37 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:18:42 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:18:42 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:18:42 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:18:47 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:18:47 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:18:47 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:18:55 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:18:55 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:18:55 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:20:42 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:20:42 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:20:42 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:21:25 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:21:25 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:21:25 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:22:05 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:22:05 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:22:05 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:22:07 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:22:07 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:22:07 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:22:26 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:22:26 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:22:26 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:22:40 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:22:40 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:22:40 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:22:42 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:22:42 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:22:42 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:22:50 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:22:50 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:22:50 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:23:03 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:23:03 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:23:03 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:23:06 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:23:06 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:23:06 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:23:27 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:23:27 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:23:27 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:23:30 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:23:30 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:23:30 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:23:31 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:23:31 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:23:31 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:23:37 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:23:37 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:23:37 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:23:38 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:23:38 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:23:38 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:23:50 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:23:50 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:23:50 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 14:53:51 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:53:59 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 18:24:20 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:24:20 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:24:20 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 14:54:20 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 18:24:22 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:24:22 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:24:22 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 14:54:22 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 18:24:23 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:24:23 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:24:23 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:25:12 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:25:12 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:25:12 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 14:55:12 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:55:18 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:55:19 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:55:24 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 18:29:29 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:29:29 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:29:29 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 14:59:29 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 18:29:32 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:29:32 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:29:32 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 14:59:32 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 14:59:38 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 15:00:12 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 18:31:02 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:31:02 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:31:02 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 15:01:02 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 18:31:32 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:31:32 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:31:32 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 15:01:33 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 18:32:41 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:32:41 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:32:41 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:34:09 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:34:09 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:34:09 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:34:19 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:34:19 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:34:19 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 15:04:29 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 18:34:35 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:34:35 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:34:35 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:34:35 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:34:35 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:34:35 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 15:04:40 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 18:35:08 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:35:08 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:35:08 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:35:09 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:35:09 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:35:09 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:35:14 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:35:14 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:35:14 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:35:18 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:35:18 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:35:18 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:35:26 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:35:26 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:35:26 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:35:29 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:35:29 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:35:29 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:36:46 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:36:46 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:36:46 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 18:38:57 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 18:38:57 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 18:38:57 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 15:13:26 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 15:13:51 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 15:13:53 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 19:28:32 --> Severity: Warning --> Attempt to read property "usn" on array C:\xampp\htdocs\mce_campus\application\views\student\profile.php 28
ERROR - 2024-09-22 19:28:32 --> Severity: Warning --> Attempt to read property "student_name" on array C:\xampp\htdocs\mce_campus\application\views\student\profile.php 40
ERROR - 2024-09-22 19:28:32 --> Severity: Warning --> Attempt to read property "academic_year" on array C:\xampp\htdocs\mce_campus\application\views\student\profile.php 53
ERROR - 2024-09-22 19:28:32 --> Severity: Warning --> Attempt to read property "stream" on array C:\xampp\htdocs\mce_campus\application\views\student\profile.php 66
ERROR - 2024-09-22 19:28:32 --> Severity: Warning --> Attempt to read property "department" on array C:\xampp\htdocs\mce_campus\application\views\student\profile.php 79
ERROR - 2024-09-22 19:28:32 --> Severity: Warning --> Attempt to read property "year" on array C:\xampp\htdocs\mce_campus\application\views\student\profile.php 92
ERROR - 2024-09-22 19:28:32 --> Severity: Warning --> Attempt to read property "college_code" on array C:\xampp\htdocs\mce_campus\application\views\student\profile.php 107
ERROR - 2024-09-22 19:28:32 --> Severity: Warning --> Attempt to read property "quota" on array C:\xampp\htdocs\mce_campus\application\views\student\profile.php 119
ERROR - 2024-09-22 19:28:32 --> Severity: Warning --> Attempt to read property "sub_quota" on array C:\xampp\htdocs\mce_campus\application\views\student\profile.php 132
ERROR - 2024-09-22 19:28:32 --> Severity: Warning --> Attempt to read property "category_allotted" on array C:\xampp\htdocs\mce_campus\application\views\student\profile.php 145
ERROR - 2024-09-22 19:28:32 --> Severity: Warning --> Attempt to read property "category_claimed" on array C:\xampp\htdocs\mce_campus\application\views\student\profile.php 158
ERROR - 2024-09-22 19:28:32 --> Severity: Warning --> Attempt to read property "caste" on array C:\xampp\htdocs\mce_campus\application\views\student\profile.php 171
ERROR - 2024-09-22 19:28:32 --> Severity: Warning --> Attempt to read property "sub_caste" on array C:\xampp\htdocs\mce_campus\application\views\student\profile.php 184
ERROR - 2024-09-22 19:28:32 --> Severity: Warning --> Attempt to read property "student_number" on array C:\xampp\htdocs\mce_campus\application\views\student\profile.php 212
ERROR - 2024-09-22 19:28:32 --> Severity: Warning --> Attempt to read property "father_number" on array C:\xampp\htdocs\mce_campus\application\views\student\profile.php 224
ERROR - 2024-09-22 19:28:32 --> Severity: Warning --> Attempt to read property "state" on array C:\xampp\htdocs\mce_campus\application\views\student\profile.php 237
ERROR - 2024-09-22 19:28:32 --> Severity: Warning --> Attempt to read property "country" on array C:\xampp\htdocs\mce_campus\application\views\student\profile.php 249
ERROR - 2024-09-22 19:28:32 --> Severity: Warning --> Attempt to read property "email" on array C:\xampp\htdocs\mce_campus\application\views\student\profile.php 262
ERROR - 2024-09-22 19:28:32 --> Severity: Warning --> Attempt to read property "gender" on array C:\xampp\htdocs\mce_campus\application\views\student\profile.php 274
ERROR - 2024-09-22 19:28:32 --> Severity: Warning --> Attempt to read property "aadhar_number" on array C:\xampp\htdocs\mce_campus\application\views\student\profile.php 286
ERROR - 2024-09-22 19:28:32 --> Severity: Warning --> Attempt to read property "date_of_birth" on array C:\xampp\htdocs\mce_campus\application\views\student\profile.php 298
ERROR - 2024-09-22 19:28:32 --> Severity: Warning --> Attempt to read property "date_of_birth" on array C:\xampp\htdocs\mce_campus\application\views\student\profile.php 298
ERROR - 2024-09-22 16:05:27 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 16:05:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-09-22 16:05:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-09-22 16:05:27 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 16:05:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-09-22 16:05:30 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 16:06:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-09-22 16:06:03 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 16:06:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-09-22 16:06:36 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 19:38:34 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 19:38:34 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 19:38:34 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 20:51:44 --> Severity: error --> Exception: syntax error, unexpected token ":", expecting ")" C:\xampp\htdocs\mce_campus\application\views\student\fees.php 32
ERROR - 2024-09-22 20:51:56 --> Severity: Warning --> Undefined variable $feesvalue C:\xampp\htdocs\mce_campus\application\views\student\fees.php 32
ERROR - 2024-09-22 21:14:38 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\mce_campus\application\views\student\fees.php 45
ERROR - 2024-09-22 21:16:58 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\profile.php 53
ERROR - 2024-09-22 21:17:00 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 21:17:00 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 21:17:00 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 17:47:07 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 21:19:21 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 26
ERROR - 2024-09-22 21:19:21 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 33
ERROR - 2024-09-22 21:19:21 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 40
ERROR - 2024-09-22 17:52:10 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 18:09:34 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 22:30:58 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\profile.php 53
ERROR - 2024-09-22 22:34:48 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\fees.php 53
ERROR - 2024-09-22 22:36:34 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\fees.php 62
ERROR - 2024-09-22 22:36:55 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-22 22:37:01 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-22 22:37:05 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-22 22:37:26 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\fees.php 67
ERROR - 2024-09-22 22:38:13 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\fees.php 54
ERROR - 2024-09-22 22:38:40 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\fees.php 57
ERROR - 2024-09-22 22:38:45 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\fees.php 53
ERROR - 2024-09-22 22:39:02 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\fees.php 56
ERROR - 2024-09-22 22:39:09 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\fees.php 54
ERROR - 2024-09-22 22:39:09 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\fees.php 227
ERROR - 2024-09-22 22:39:50 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\fees.php 54
ERROR - 2024-09-22 22:39:50 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\fees.php 227
ERROR - 2024-09-22 22:40:59 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\fees.php 77
ERROR - 2024-09-22 22:41:39 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\fees.php 83
ERROR - 2024-09-22 22:41:54 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\fees.php 79
ERROR - 2024-09-22 19:11:58 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 22:42:33 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\fees.php 79
ERROR - 2024-09-22 19:12:33 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 22:42:51 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\fees.php 79
ERROR - 2024-09-22 19:12:51 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 22:43:05 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\fees.php 81
ERROR - 2024-09-22 19:13:05 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 22:43:34 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\fees.php 82
ERROR - 2024-09-22 19:13:34 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 22:43:49 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\fees.php 82
ERROR - 2024-09-22 19:13:49 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 22:44:08 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\fees.php 82
ERROR - 2024-09-22 19:14:08 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 22:44:46 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\fees.php 83
ERROR - 2024-09-22 19:14:47 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 22:44:53 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\fees.php 83
ERROR - 2024-09-22 19:14:53 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 22:45:25 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\fees.php 83
ERROR - 2024-09-22 19:15:25 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 22:47:40 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\fees.php 83
ERROR - 2024-09-22 19:17:40 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 22:48:34 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\fees.php 83
ERROR - 2024-09-22 19:18:34 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 19:19:57 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 19:20:11 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 19:20:57 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 22:55:07 --> Severity: Warning --> Undefined property: stdClass::$academic_year C:\xampp\htdocs\mce_campus\application\views\student\profile.php 53
ERROR - 2024-09-22 19:25:09 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 19:25:27 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 19:26:45 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 19:27:04 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 19:27:52 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 23:11:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\mce_campus\application\views\student\fees.php 190
ERROR - 2024-09-22 23:11:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\mce_campus\application\views\student\fees.php 190
ERROR - 2024-09-22 23:14:09 --> Severity: Warning --> Undefined variable $187735 C:\xampp\htdocs\mce_campus\application\views\student\fees.php 200
ERROR - 2024-09-22 20:30:37 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 20:31:29 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 20:31:31 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 22:53:43 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-22 22:57:44 --> 404 Page Not Found: Assets/js
