<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-09-25 15:54:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\xampp\htdocs\mce_campus\application\libraries\Logger.php 143
ERROR - 2024-09-25 15:59:12 --> Severity: error --> Exception: Too few arguments to function generateCopy(), 15 passed in F:\xampp\htdocs\mce_campus\application\controllers\Admin.php on line 1631 and exactly 16 expected F:\xampp\htdocs\mce_campus\application\controllers\Admin.php 1536
ERROR - 2024-09-25 19:52:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\xampp\htdocs\mce_campus\application\libraries\Logger.php 143
ERROR - 2024-09-25 19:52:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\xampp\htdocs\mce_campus\application\libraries\Logger.php 143
ERROR - 2024-09-25 19:52:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\xampp\htdocs\mce_campus\application\libraries\Logger.php 143
ERROR - 2024-09-25 19:52:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\xampp\htdocs\mce_campus\application\libraries\Logger.php 143
ERROR - 2024-09-25 19:52:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\xampp\htdocs\mce_campus\application\libraries\Logger.php 143
ERROR - 2024-09-25 19:52:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\xampp\htdocs\mce_campus\application\libraries\Logger.php 143
