<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-09-25 15:41:17 --> Severity: error --> Exception: Wrong number of segments F:\xampp\htdocs\mce_campus\application\libraries\Jwt.php 16
ERROR - 2024-09-25 15:42:53 --> Severity: error --> Exception: Wrong number of segments F:\xampp\htdocs\mce_campus\application\libraries\Jwt.php 16
ERROR - 2024-09-25 15:43:13 --> Severity: error --> Exception: Wrong number of segments F:\xampp\htdocs\mce_campus\application\libraries\Jwt.php 16
ERROR - 2024-09-25 15:43:49 --> Severity: error --> Exception: Wrong number of segments F:\xampp\htdocs\mce_campus\application\libraries\Jwt.php 16
ERROR - 2024-09-25 15:46:46 --> Severity: error --> Exception: Wrong number of segments F:\xampp\htdocs\mce_campus\application\libraries\Jwt.php 16
ERROR - 2024-09-25 15:54:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\xampp\htdocs\mce_campus\application\libraries\Logger.php 143
ERROR - 2024-09-25 15:54:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\xampp\htdocs\mce_campus\application\libraries\Logger.php 143
ERROR - 2024-09-25 15:54:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\xampp\htdocs\mce_campus\application\libraries\Logger.php 143
ERROR - 2024-09-25 15:54:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\xampp\htdocs\mce_campus\application\libraries\Logger.php 143
ERROR - 2024-09-25 15:54:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\xampp\htdocs\mce_campus\application\libraries\Logger.php 143
ERROR - 2024-09-25 15:54:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\xampp\htdocs\mce_campus\application\libraries\Logger.php 143
