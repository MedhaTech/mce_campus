<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-09-25 21:52:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\xampp\htdocs\mce_campus\application\libraries\Logger.php 143
ERROR - 2024-09-25 21:56:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\xampp\htdocs\mce_campus\application\libraries\Logger.php 143
ERROR - 2024-09-25 21:56:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\xampp\htdocs\mce_campus\application\libraries\Logger.php 143
