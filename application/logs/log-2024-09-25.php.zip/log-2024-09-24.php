<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-09-24 10:42:18 --> Query error: Unknown column 'usn' in 'where clause' - Invalid query: SELECT *
FROM `transactions`
WHERE `usn` = '4MC23CV001'
ERROR - 2024-09-24 07:25:47 --> 404 Page Not Found: Student/downloadReceipt
ERROR - 2024-09-24 07:28:05 --> 404 Page Not Found: Assets/img
ERROR - 2024-09-24 10:58:05 --> Severity: Warning --> getimagesize(http://127.0.0.1/mce_campus/assets/img/transaction1.jpg): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 F:\xampp\htdocs\mce_campus\application\libraries\Fpdf.php 1301
ERROR - 2024-09-24 10:58:05 --> Severity: error --> Exception: FPDF error: Missing or incorrect image file: http://127.0.0.1/mce_campus/assets/img/transaction1.jpg F:\xampp\htdocs\mce_campus\application\libraries\Fpdf.php 276
ERROR - 2024-09-24 13:41:28 --> Severity: Warning --> Undefined property: stdClass::$flow C:\xampp\htdocs\mce_campus\application\controllers\Student.php 62
ERROR - 2024-09-24 13:41:31 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:41:31 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:41:31 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:41:31 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:41:31 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:41:31 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:41:31 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:41:31 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:41:31 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:41:31 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:41:31 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:41:31 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:41:31 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:41:31 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:41:31 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:41:31 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:41:31 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:41:31 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:41:31 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:41:31 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:43:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:43:32 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:43:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:43:32 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:43:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:43:32 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:43:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:43:32 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:43:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:43:32 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:43:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:43:32 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:43:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:43:32 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:43:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:43:32 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:43:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:43:32 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:43:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:43:32 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:43:47 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:43:47 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:43:47 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:43:47 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:43:47 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:43:47 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:43:47 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:43:47 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:43:47 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:43:47 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:43:47 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:43:47 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:43:47 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:43:47 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:43:47 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:43:47 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:43:47 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:43:47 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:43:47 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:43:47 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:46:12 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:46:12 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:46:12 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:46:12 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:46:12 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:46:12 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:46:12 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:46:12 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:46:12 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:46:12 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:46:12 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:46:12 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:46:12 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:46:12 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:46:12 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:46:12 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:46:12 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:46:12 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:46:12 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:46:12 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:46:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\mce_campus\application\views\student\fees.php 190
ERROR - 2024-09-24 13:46:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\mce_campus\application\views\student\fees.php 190
ERROR - 2024-09-24 13:46:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:46:24 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:46:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:46:24 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:46:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:46:24 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:46:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:46:24 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:46:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:46:24 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:46:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:46:24 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:46:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:46:24 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:46:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:46:24 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:46:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:46:24 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:46:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:46:24 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:46:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\mce_campus\application\views\student\fees.php 190
ERROR - 2024-09-24 13:46:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\mce_campus\application\views\student\fees.php 190
ERROR - 2024-09-24 13:46:41 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:46:41 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:46:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:46:42 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:46:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:46:42 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:46:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:46:42 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:46:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:46:42 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:46:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:46:42 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:46:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:46:42 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:46:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:46:42 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:46:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:46:42 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:46:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:46:42 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:46:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\mce_campus\application\views\student\fees.php 190
ERROR - 2024-09-24 13:46:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\mce_campus\application\views\student\fees.php 190
ERROR - 2024-09-24 13:46:56 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:46:56 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:46:56 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:46:56 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:46:56 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:46:56 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:46:56 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:46:56 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:46:56 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:46:56 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:46:56 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:46:56 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:46:56 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:46:56 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:46:56 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:46:56 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:46:56 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:46:56 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:46:56 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:46:56 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:47:01 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:47:01 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:47:01 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:47:01 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:47:01 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:47:01 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:47:01 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:47:01 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:47:01 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:47:01 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:47:01 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:47:01 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:47:01 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:47:01 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:47:01 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:47:01 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:47:01 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:47:01 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:47:01 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:47:01 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:47:14 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:47:14 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:47:14 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:47:14 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:47:14 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:47:14 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:47:14 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:47:14 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:47:14 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:47:14 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:47:14 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:47:14 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:47:14 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:47:14 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:47:14 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:47:14 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:47:14 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:47:14 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:47:14 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:47:14 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:47:29 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:47:29 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:47:29 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:47:29 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:47:29 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:47:29 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:47:29 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:47:29 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:47:29 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:47:29 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:47:29 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:47:29 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:47:29 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:47:29 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:47:29 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:47:29 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:47:29 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:47:29 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:47:29 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:47:29 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:47:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:47:48 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:47:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:47:48 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:47:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:47:48 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:47:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:47:48 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:47:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:47:48 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:47:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:47:48 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:47:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:47:48 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:47:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:47:48 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:47:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:47:48 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:47:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:47:48 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:47:53 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:47:53 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:47:53 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:47:53 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:47:53 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:47:53 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:47:53 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:47:53 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:47:53 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:47:53 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:47:53 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:47:53 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:47:53 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:47:53 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:47:53 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:47:53 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:47:53 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:47:53 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:47:53 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:47:53 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:48:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:48:08 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:48:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:48:08 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:48:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:48:08 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:48:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:48:08 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:48:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:48:08 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:48:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:48:08 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:48:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:48:08 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:48:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:48:08 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:48:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:48:08 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:48:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:48:08 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:48:10 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:48:10 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:48:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:48:11 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:48:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:48:11 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:48:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:48:11 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:48:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:48:11 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:48:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:48:11 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:48:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:48:11 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:48:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:48:11 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:48:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:48:11 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:48:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:48:11 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:48:13 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:48:13 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:48:13 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:48:13 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:48:13 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:48:13 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:48:13 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:48:13 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:48:13 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:48:13 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:48:13 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:48:13 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:48:13 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:48:13 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:48:13 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:48:13 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:48:13 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:48:13 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:48:13 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:48:13 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:48:18 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:48:18 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:48:18 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:48:18 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:48:18 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:48:18 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:48:18 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:48:18 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:48:18 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:48:18 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:48:18 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:48:18 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:48:18 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:48:18 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:48:18 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:48:18 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:48:18 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:48:18 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:48:18 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:48:18 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:48:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:48:25 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 13:48:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:48:25 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 13:48:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:48:25 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 13:48:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:48:25 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 13:48:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:48:25 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 13:48:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:48:25 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 13:48:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:48:25 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 13:48:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:48:25 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 13:48:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:48:25 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 13:48:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 13:48:25 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:03:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:03:39 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:03:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:03:39 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:03:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:03:39 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:03:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:03:39 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:03:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:03:39 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:03:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:03:39 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:03:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:03:39 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:03:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:03:39 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:03:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:03:39 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:03:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:03:39 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:04:14 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:04:14 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:04:14 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:04:14 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:04:14 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:04:14 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:04:14 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:04:14 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:04:14 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:04:14 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:04:14 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:04:14 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:04:14 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:04:14 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:04:14 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:04:14 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:04:14 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:04:14 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:04:14 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:04:14 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:04:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:04:42 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:04:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:04:42 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:04:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:04:42 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:04:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:04:42 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:04:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:04:42 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:04:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:04:42 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:04:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:04:42 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:04:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:04:42 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:04:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:04:42 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:04:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:04:42 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:05:37 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:05:37 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:05:37 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:05:37 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:05:37 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:05:37 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:05:37 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:05:37 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:05:37 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:05:37 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:05:37 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:05:37 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:05:37 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:05:37 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:05:37 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:05:37 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:05:37 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:05:37 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:05:37 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:05:37 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:08:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:08:24 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:08:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:08:24 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:08:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:08:24 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:08:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:08:24 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:08:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:08:24 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:08:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:08:24 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:08:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:08:24 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:08:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:08:24 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:08:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:08:24 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:08:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:08:24 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:16:09 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:16:09 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:16:09 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:16:09 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:16:09 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:16:09 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:16:09 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:16:09 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:16:09 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:16:09 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:16:09 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:16:09 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:16:09 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:16:09 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:16:09 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:16:09 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:16:09 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:16:09 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:16:09 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:16:09 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:17:07 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:17:07 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:17:07 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:17:07 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:17:07 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:17:07 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:17:07 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:17:07 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:17:07 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:17:07 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:17:07 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:17:07 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:17:07 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:17:07 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:17:07 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:17:07 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:17:07 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:17:07 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:17:07 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:17:07 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:17:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:17:57 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:17:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:17:57 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:17:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:17:57 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:17:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:17:57 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:17:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:17:57 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:17:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:17:57 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:17:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:17:57 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:17:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:17:57 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:17:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:17:57 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:17:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:17:57 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:18:06 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:18:06 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:18:06 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:18:06 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:18:06 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:18:06 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:18:06 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:18:06 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:18:06 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:18:06 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:18:06 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:18:06 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:18:06 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:18:06 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:18:06 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:18:06 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:18:06 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:18:06 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:18:06 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:18:06 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:18:09 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:18:09 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:18:09 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:18:09 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:18:09 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:18:09 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:18:09 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:18:09 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:18:09 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:18:09 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:18:09 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:18:09 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:18:09 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:18:09 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:18:09 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:18:09 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:18:09 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:18:09 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:18:09 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:18:09 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:18:23 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:18:23 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:18:23 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:18:23 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:18:23 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:18:23 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:18:23 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:18:23 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:18:23 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:18:23 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:18:23 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:18:23 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:18:23 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:18:23 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:18:23 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:18:23 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:18:23 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:18:23 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:18:23 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:18:23 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 10:48:26 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 14:35:35 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:35:35 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:35:35 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:35:35 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:35:35 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:35:35 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:35:35 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:35:35 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:35:35 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:35:35 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:35:35 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:35:35 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:35:35 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:35:35 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:35:35 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:35:35 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:35:35 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:35:35 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:35:35 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:35:35 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:05:35 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 14:36:04 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:36:04 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:36:04 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:36:04 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:36:04 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:36:04 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:36:04 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:36:04 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:36:04 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:36:04 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:36:04 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:36:04 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:36:04 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:36:04 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:36:04 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:36:04 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:36:04 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:36:04 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:36:04 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:36:04 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:06:04 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 14:36:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:36:24 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:36:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:36:24 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:36:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:36:24 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:36:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:36:24 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:36:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:36:24 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:36:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:36:24 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:36:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:36:24 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:36:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:36:24 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:36:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:36:24 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:36:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:36:24 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:06:24 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 14:36:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:36:26 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:36:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:36:26 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:36:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:36:26 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:36:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:36:26 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:36:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:36:26 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:36:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:36:26 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:36:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:36:26 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:36:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:36:26 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:36:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:36:26 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:36:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:36:26 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:06:26 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 14:37:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:37:11 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:37:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:37:11 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:37:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:37:11 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:37:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:37:11 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:37:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:37:11 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:37:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:37:11 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:37:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:37:11 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:37:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:37:11 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:37:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:37:11 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:37:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:37:11 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:37:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:37:40 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:37:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:37:40 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:37:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:37:40 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:37:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:37:40 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:37:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:37:40 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:37:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:37:40 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:37:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:37:40 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:37:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:37:40 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:37:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:37:40 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:37:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:37:40 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:37:41 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:37:41 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:37:41 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:37:41 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:37:41 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:37:41 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:37:41 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:37:41 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:37:41 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:37:41 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:37:41 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:37:41 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:37:41 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:37:41 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:37:41 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:37:41 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:37:41 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:37:41 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:37:41 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:37:41 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:37:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:37:42 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:37:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:37:42 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:37:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:37:42 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:37:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:37:42 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:37:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:37:42 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:37:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:37:42 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:37:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:37:42 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:37:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:37:42 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:37:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:37:42 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:37:42 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:37:42 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:37:54 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:37:54 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:37:55 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:37:55 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:37:55 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:37:55 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:37:55 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:37:55 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:37:55 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:37:55 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:37:55 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:37:55 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:37:55 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:37:55 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:37:55 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:37:55 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:37:55 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:37:55 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:37:55 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:37:55 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:38:10 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:38:10 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:38:10 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:38:10 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:38:10 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:38:10 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:38:10 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:38:10 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:38:10 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:38:10 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:38:10 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:38:10 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:38:10 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:38:10 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:38:10 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:38:10 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:38:10 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:38:10 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:38:10 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:38:10 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:38:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:38:24 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:38:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:38:24 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:38:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:38:24 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:38:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:38:24 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:38:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:38:24 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:38:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:38:24 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:38:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:38:24 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:38:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:38:24 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:38:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:38:24 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:38:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:38:24 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:38:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:38:39 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:38:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:38:39 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:38:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:38:39 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:38:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:38:39 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:38:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:38:39 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:38:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:38:39 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:38:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:38:39 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:38:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:38:39 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:38:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:38:39 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:38:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:38:39 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:39:04 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:39:04 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:39:04 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:39:04 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:39:04 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:39:04 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:39:04 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:39:04 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:39:04 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:39:04 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:39:04 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:39:04 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:39:04 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:39:04 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:39:04 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:39:04 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:39:04 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:39:04 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:39:04 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:39:04 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:39:34 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:39:34 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:39:34 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:39:34 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:39:34 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:39:34 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:39:34 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:39:34 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:39:34 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:39:34 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:39:34 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:39:34 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:39:34 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:39:34 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:39:34 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:39:34 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:39:34 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:39:34 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:39:34 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:39:34 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:40:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:40:32 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:40:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:40:32 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:40:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:40:32 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:40:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:40:32 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:40:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:40:32 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:40:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:40:32 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:40:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:40:32 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:40:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:40:32 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:40:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:40:32 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:40:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:40:32 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:41:38 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:41:38 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:41:38 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:41:38 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:41:38 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:41:38 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:41:38 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:41:38 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:41:38 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:41:38 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:41:38 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:41:38 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:41:38 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:41:38 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:41:38 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:41:38 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:41:38 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:41:38 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:41:38 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:41:38 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:41:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:41:39 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:41:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:41:39 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:41:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:41:39 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:41:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:41:39 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:41:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:41:39 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:41:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:41:39 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:41:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:41:39 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:41:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:41:39 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:41:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:41:39 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:41:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:41:39 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:41:40 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:41:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:41:48 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:41:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:41:48 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:41:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:41:48 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:41:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:41:48 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:41:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:41:48 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:41:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:41:48 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:41:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:41:48 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:41:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:41:48 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:41:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:41:48 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:41:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:41:48 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:41:49 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:41:49 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:41:49 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:41:49 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:41:49 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:41:49 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:41:49 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:41:49 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:41:49 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:41:49 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:41:49 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:41:49 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:41:49 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:41:49 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:41:49 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:41:49 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:41:49 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:41:49 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:41:49 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:41:49 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:41:56 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:41:56 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:41:56 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:41:56 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:41:56 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:41:56 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:41:56 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:41:56 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:41:56 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:41:56 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:41:56 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:41:56 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:41:56 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:41:56 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:41:56 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:41:56 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:41:56 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:41:56 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:41:56 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:41:56 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:43:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:43:24 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:43:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:43:24 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:43:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:43:24 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:43:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:43:24 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:43:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:43:24 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:43:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:43:24 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:43:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:43:24 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:43:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:43:24 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:43:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:43:24 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:43:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:43:24 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:43:26 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:13:30 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 14:44:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:44:24 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:44:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:44:24 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:44:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:44:24 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:44:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:44:24 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:44:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:44:24 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:44:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:44:24 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:44:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:44:24 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:44:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:44:24 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:44:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:44:24 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:44:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:44:24 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:14:24 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 14:44:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:44:48 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:44:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:44:48 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:44:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:44:48 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:44:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:44:48 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:44:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:44:48 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:44:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:44:48 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:44:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:44:48 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:44:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:44:48 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:44:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:44:48 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:44:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:44:48 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:14:48 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 14:45:55 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:45:55 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:45:55 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:45:55 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:45:55 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:45:55 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:45:55 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:45:55 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:45:55 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:45:55 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:45:55 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:45:55 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:45:55 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:45:55 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:45:55 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:45:55 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:45:55 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:45:55 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:45:55 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:45:55 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:15:56 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 14:45:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:45:57 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:45:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:45:57 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:45:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:45:57 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:45:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:45:57 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:45:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:45:57 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:45:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:45:57 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:45:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:45:57 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:45:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:45:57 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:45:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:45:57 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:45:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:45:57 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:15:57 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 14:46:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:46:08 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:46:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:46:08 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:46:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:46:08 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:46:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:46:08 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:46:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:46:08 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:46:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:46:08 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:46:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:46:08 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:46:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:46:08 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:46:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:46:08 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:46:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:46:08 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:16:08 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 14:46:20 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:46:20 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:46:20 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:46:20 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:46:20 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:46:20 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:46:20 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:46:20 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:46:20 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:46:20 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:46:20 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:46:20 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:46:20 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:46:20 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:46:20 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:46:20 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:46:20 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:46:20 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:46:20 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:46:20 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:16:20 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 14:46:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:46:24 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:46:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:46:24 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:46:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:46:24 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:46:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:46:24 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:46:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:46:24 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:46:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:46:24 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:46:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:46:24 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:46:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:46:24 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:46:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:46:24 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:46:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:46:24 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:16:24 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 14:46:47 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:46:47 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:46:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:46:48 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:46:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:46:48 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:46:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:46:48 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:46:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:46:48 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:46:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:46:48 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:46:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:46:48 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:46:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:46:48 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:46:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:46:48 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:46:48 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:46:48 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:16:48 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 11:28:17 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 14:58:37 --> Severity: Warning --> Undefined property: stdClass::$flow C:\xampp\htdocs\mce_campus\application\controllers\Student.php 62
ERROR - 2024-09-24 11:28:38 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 14:58:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:58:39 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:58:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:58:39 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:58:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:58:39 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:58:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:58:39 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:58:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:58:39 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:58:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:58:39 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:58:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:58:39 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:58:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:58:39 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:58:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:58:39 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:58:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:58:39 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:28:39 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 14:59:51 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:59:51 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 14:59:51 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:59:51 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 14:59:51 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:59:51 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 14:59:51 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:59:51 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 14:59:51 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:59:51 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 14:59:51 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:59:51 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 14:59:51 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:59:51 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 14:59:51 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:59:51 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 14:59:51 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:59:51 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 14:59:51 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 14:59:51 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:29:51 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 15:01:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:01:11 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:01:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:01:11 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:01:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:01:11 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:01:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:01:11 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:01:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:01:11 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:01:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:01:11 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:01:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:01:11 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:01:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:01:11 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:01:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:01:11 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:01:11 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:01:11 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:31:11 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 15:01:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:01:39 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:01:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:01:39 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:01:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:01:39 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:01:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:01:39 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:01:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:01:39 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:01:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:01:39 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:01:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:01:39 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:01:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:01:39 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:01:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:01:39 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:01:39 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:01:39 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:31:39 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 15:01:52 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:01:52 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:01:52 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:01:52 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:01:52 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:01:52 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:01:52 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:01:52 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:01:52 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:01:52 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:01:52 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:01:52 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:01:52 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:01:52 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:01:52 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:01:52 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:01:52 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:01:52 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:01:52 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:01:52 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:31:52 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 15:01:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:01:57 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:01:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:01:57 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:01:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:01:57 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:01:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:01:57 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:01:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:01:57 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:01:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:01:57 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:01:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:01:57 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:01:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:01:57 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:01:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:01:57 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:01:57 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:01:57 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:31:57 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 15:02:15 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:02:15 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:02:15 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:02:15 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:02:15 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:02:15 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:02:15 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:02:15 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:02:15 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:02:15 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:02:15 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:02:15 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:02:15 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:02:15 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:02:15 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:02:15 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:02:15 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:02:15 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:02:15 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:02:15 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:32:15 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 15:03:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:03:40 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:03:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:03:40 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:03:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:03:40 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:03:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:03:40 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:03:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:03:40 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:03:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:03:40 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:03:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:03:40 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:03:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:03:40 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:03:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:03:40 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:03:40 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:03:40 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:33:40 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 15:04:10 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:04:10 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:04:10 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:04:10 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:04:10 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:04:10 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:04:10 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:04:10 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:04:10 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:04:10 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:04:10 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:04:10 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:04:10 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:04:10 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:04:10 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:04:10 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:04:10 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:04:10 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:04:10 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:04:10 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:34:10 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 15:06:43 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:06:43 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:06:43 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:06:43 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:06:43 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:06:43 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:06:43 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:06:43 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:06:43 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:06:43 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:06:43 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:06:43 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:06:43 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:06:43 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:06:43 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:06:43 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:06:43 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:06:43 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:06:43 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:06:43 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:36:43 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 15:06:45 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:06:45 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:06:45 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:06:45 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:06:45 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:06:45 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:06:45 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:06:45 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:06:45 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:06:45 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:06:45 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:06:45 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:06:45 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:06:45 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:06:45 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:06:45 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:06:45 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:06:45 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:06:45 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:06:45 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:36:45 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 15:07:03 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:07:03 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:07:03 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:07:03 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:07:03 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:07:03 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:07:03 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:07:03 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:07:03 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:07:03 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:07:03 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:07:03 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:07:03 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:07:03 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:07:03 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:07:03 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:07:03 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:07:03 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:07:03 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:07:03 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:37:03 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 15:07:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:07:08 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:07:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:07:08 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:07:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:07:08 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:07:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:07:08 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:07:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:07:08 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:07:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:07:08 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:07:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:07:08 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:07:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:07:08 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:07:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:07:08 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:07:08 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:07:08 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:37:08 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 15:07:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:07:25 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:07:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:07:25 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:07:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:07:25 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:07:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:07:25 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:07:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:07:25 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:07:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:07:25 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:07:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:07:25 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:07:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:07:25 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:07:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:07:25 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:07:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:07:25 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:37:25 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 15:09:28 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:09:28 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:09:28 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:09:28 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:09:28 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:09:28 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:09:28 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:09:28 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:09:28 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:09:28 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:09:28 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:09:28 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:09:28 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:09:28 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:09:28 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:09:28 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:09:28 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:09:28 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:09:28 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:09:28 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:09:28 --> Severity: Warning --> Undefined variable $number C:\xampp\htdocs\mce_campus\application\helpers\custom_helper.php 69
ERROR - 2024-09-24 15:09:28 --> Severity: Warning --> Undefined variable $number C:\xampp\htdocs\mce_campus\application\helpers\custom_helper.php 69
ERROR - 2024-09-24 11:39:28 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 15:09:35 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:09:35 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:09:35 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:09:35 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:09:35 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:09:35 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:09:35 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:09:35 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:09:35 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:09:35 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:09:35 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:09:35 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:09:35 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:09:35 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:09:35 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:09:35 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:09:35 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:09:35 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:09:35 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:09:35 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:09:35 --> Severity: Warning --> Undefined variable $number C:\xampp\htdocs\mce_campus\application\helpers\custom_helper.php 69
ERROR - 2024-09-24 15:09:35 --> Severity: Warning --> Undefined variable $number C:\xampp\htdocs\mce_campus\application\helpers\custom_helper.php 69
ERROR - 2024-09-24 11:39:35 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 15:10:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:10:24 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:10:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:10:24 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:10:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:10:24 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:10:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:10:24 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:10:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:10:24 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:10:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:10:24 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:10:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:10:24 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:10:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:10:24 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:10:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:10:24 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:10:24 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:10:24 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:10:24 --> Severity: error --> Exception: number_format(): Argument #1 ($num) must be of type float, string given C:\xampp\htdocs\mce_campus\application\helpers\custom_helper.php 69
ERROR - 2024-09-24 15:10:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:10:25 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:10:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:10:25 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:10:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:10:25 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:10:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:10:25 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:10:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:10:25 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:10:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:10:25 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:10:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:10:25 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:10:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:10:25 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:10:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:10:25 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:10:25 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:10:25 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:10:25 --> Severity: error --> Exception: number_format(): Argument #1 ($num) must be of type float, string given C:\xampp\htdocs\mce_campus\application\helpers\custom_helper.php 69
ERROR - 2024-09-24 15:10:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:10:32 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:10:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:10:32 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:10:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:10:32 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:10:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:10:32 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:10:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:10:32 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:10:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:10:32 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:10:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:10:32 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:10:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:10:32 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:10:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:10:32 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:10:32 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:10:32 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:40:32 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 15:10:54 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:10:54 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:10:54 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:10:54 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:10:54 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:10:54 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:10:54 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:10:54 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:10:54 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:10:54 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:10:54 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:10:54 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:10:54 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:10:54 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:10:54 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:10:54 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:10:54 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:10:54 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:10:54 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:10:54 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:40:54 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 15:11:13 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:11:13 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:11:13 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:11:13 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:11:13 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:11:13 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:11:13 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:11:13 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:11:13 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:11:13 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:11:13 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:11:13 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:11:13 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:11:13 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:11:13 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:11:13 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:11:13 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:11:13 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:11:13 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:11:13 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:41:13 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 15:11:44 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:11:44 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:11:44 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:11:44 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:11:44 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:11:44 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:11:44 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:11:44 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:11:44 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:11:44 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:11:44 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:11:44 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:11:44 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:11:44 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:11:44 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:11:44 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:11:44 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:11:44 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:11:44 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:11:44 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:11:44 --> Severity: error --> Exception: number_format(): Argument #1 ($num) must be of type float, string given C:\xampp\htdocs\mce_campus\application\helpers\custom_helper.php 69
ERROR - 2024-09-24 15:11:53 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:11:53 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:11:53 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:11:53 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:11:53 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:11:53 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:11:53 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:11:53 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:11:53 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:11:53 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:11:53 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:11:53 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:11:53 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:11:53 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:11:53 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:11:53 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:11:53 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:11:53 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:11:53 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:11:53 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:11:53 --> Severity: error --> Exception: number_format(): Argument #1 ($num) must be of type float, string given C:\xampp\htdocs\mce_campus\application\helpers\custom_helper.php 69
ERROR - 2024-09-24 15:11:58 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:11:58 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:11:58 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:11:58 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:11:58 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:11:58 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:11:58 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:11:58 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:11:58 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:11:58 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:11:58 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:11:58 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:11:58 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:11:58 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:11:58 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:11:58 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:11:58 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:11:58 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:11:58 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:11:58 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:41:58 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 15:12:03 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:12:03 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:12:03 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:12:03 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:12:03 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:12:03 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:12:03 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:12:03 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:12:03 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:12:03 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:12:03 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:12:03 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:12:03 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:12:03 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:12:03 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:12:03 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:12:03 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:12:03 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:12:03 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:12:03 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:12:03 --> Severity: error --> Exception: number_format(): Argument #1 ($num) must be of type float, string given C:\xampp\htdocs\mce_campus\application\helpers\custom_helper.php 69
ERROR - 2024-09-24 15:12:21 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:12:21 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:12:21 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:12:21 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:12:21 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:12:21 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:12:21 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:12:21 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:12:21 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:12:21 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:12:21 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:12:21 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:12:21 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:12:21 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:12:21 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:12:21 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:12:21 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:12:21 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:12:21 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:12:21 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:42:21 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 15:12:31 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:12:31 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:12:31 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:12:31 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:12:31 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:12:31 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:12:31 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:12:31 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:12:31 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:12:31 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:12:31 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:12:31 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:12:31 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:12:31 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:12:31 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:12:31 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:12:31 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:12:31 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:12:31 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:12:31 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:42:32 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 15:12:36 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:12:36 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:12:36 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:12:36 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:12:36 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:12:36 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:12:36 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:12:36 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:12:36 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:12:36 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:12:36 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:12:36 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:12:36 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:12:36 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:12:36 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:12:36 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:12:36 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:12:36 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:12:36 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:12:36 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:42:36 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 15:12:45 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:12:45 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:12:45 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:12:45 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:12:45 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:12:45 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:12:45 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:12:45 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:12:45 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:12:45 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:12:45 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:12:45 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:12:45 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:12:45 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:12:45 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:12:45 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:12:45 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:12:45 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:12:45 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:12:45 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:42:45 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 15:20:12 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:20:12 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:20:12 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:20:12 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:20:12 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:20:12 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:20:12 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:20:12 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:20:12 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:20:12 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:20:12 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:20:12 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:20:12 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:20:12 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:20:12 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:20:12 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:20:12 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:20:12 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:20:12 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:20:12 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:50:13 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-24 15:26:46 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:26:46 --> Severity: Warning --> Attempt to read property "usn" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 28
ERROR - 2024-09-24 15:26:46 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:26:46 --> Severity: Warning --> Attempt to read property "student_name" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 40
ERROR - 2024-09-24 15:26:46 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:26:46 --> Severity: Warning --> Attempt to read property "stream" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 52
ERROR - 2024-09-24 15:26:46 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:26:46 --> Severity: Warning --> Attempt to read property "department" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 64
ERROR - 2024-09-24 15:26:46 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:26:46 --> Severity: Warning --> Attempt to read property "college_code" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 76
ERROR - 2024-09-24 15:26:46 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:26:46 --> Severity: Warning --> Attempt to read property "quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 88
ERROR - 2024-09-24 15:26:46 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:26:46 --> Severity: Warning --> Attempt to read property "sub_quota" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 100
ERROR - 2024-09-24 15:26:46 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:26:46 --> Severity: Warning --> Attempt to read property "category_allotted" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 112
ERROR - 2024-09-24 15:26:46 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:26:46 --> Severity: Warning --> Attempt to read property "category_claimed" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 124
ERROR - 2024-09-24 15:26:46 --> Severity: Warning --> Undefined variable $details C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 15:26:46 --> Severity: Warning --> Attempt to read property "caste" on null C:\xampp\htdocs\mce_campus\application\views\student\fees.php 136
ERROR - 2024-09-24 11:56:46 --> 404 Page Not Found: Assets/js
