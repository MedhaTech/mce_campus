<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-09-21 07:20:19 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 99
ERROR - 2024-09-21 03:51:22 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-21 03:51:23 --> 404 Page Not Found: Assets/plugins
