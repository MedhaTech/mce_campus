<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-09-19 12:39:17 --> Severity: Warning --> Undefined property: Student::$student_template C:\xampp\htdocs\mce_campus\application\controllers\Student.php 67
ERROR - 2024-09-19 12:39:17 --> Severity: error --> Exception: Call to a member function show() on null C:\xampp\htdocs\mce_campus\application\controllers\Student.php 67
ERROR - 2024-09-19 12:45:44 --> Severity: Warning --> Undefined variable $full_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-19 09:16:20 --> 404 Page Not Found: Admin/students
ERROR - 2024-09-19 12:46:22 --> Severity: Warning --> Undefined variable $full_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-19 12:51:53 --> Severity: Warning --> Undefined variable $full_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-19 12:51:55 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-19 12:51:55 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-19 12:51:55 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-19 09:22:26 --> 404 Page Not Found: Admin/students
ERROR - 2024-09-19 12:52:28 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-19 12:52:28 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-19 12:52:28 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-19 12:52:33 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-19 12:52:33 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-19 12:52:33 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-19 12:52:40 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-19 12:52:40 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-19 12:52:40 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-19 09:22:42 --> 404 Page Not Found: Admin/students
ERROR - 2024-09-19 12:52:44 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-19 12:52:44 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-19 12:52:44 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-19 12:53:32 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-19 12:53:32 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-19 12:53:32 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-19 12:53:33 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-19 12:53:33 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-19 12:53:33 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-19 12:53:36 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-19 12:53:36 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-19 12:53:36 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-19 12:54:05 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-19 12:54:05 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-19 12:54:05 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-19 12:54:08 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-19 12:54:08 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-19 12:54:08 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-19 09:24:11 --> 404 Page Not Found: Admin/students
ERROR - 2024-09-19 12:54:14 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-19 12:54:14 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-19 12:54:14 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-19 12:55:03 --> Severity: Warning --> Undefined variable $full_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-19 12:55:13 --> Severity: Warning --> Undefined variable $full_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-19 12:55:18 --> Severity: Warning --> Undefined variable $full_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-19 09:25:19 --> 404 Page Not Found: Admin/students
ERROR - 2024-09-19 12:55:22 --> Severity: Warning --> Undefined variable $full_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-19 12:55:57 --> Severity: Warning --> Undefined variable $full_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-19 09:26:01 --> 404 Page Not Found: Student/students
ERROR - 2024-09-19 12:56:03 --> Severity: Warning --> Undefined variable $full_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-19 12:56:04 --> Severity: Warning --> Undefined variable $full_name C:\xampp\htdocs\mce_campus\application\views\student\template\header.php 74
ERROR - 2024-09-19 12:56:04 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-19 12:56:04 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-19 12:56:04 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-19 12:58:38 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-19 12:58:38 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-19 12:58:38 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-19 13:00:19 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-19 13:00:19 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-19 13:00:19 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-19 13:02:57 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-19 13:02:57 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-19 13:02:57 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-19 13:03:06 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-19 13:03:06 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-19 13:03:06 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-19 13:03:23 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-19 13:03:23 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-19 13:03:23 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-19 13:04:02 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-19 13:04:02 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-19 13:04:02 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-19 13:04:16 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-19 13:04:16 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-19 13:04:16 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-19 13:06:04 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-19 13:06:04 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-19 13:06:04 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-19 13:10:00 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-19 13:10:00 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-19 13:10:00 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-19 13:10:21 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-19 13:10:21 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-19 13:10:21 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-19 13:18:08 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-19 13:18:08 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-19 13:18:08 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-19 13:28:02 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-19 13:28:02 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-19 13:28:02 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-19 13:28:53 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-19 13:28:53 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-19 13:28:53 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-19 10:04:20 --> 404 Page Not Found: Admin/students
ERROR - 2024-09-19 13:34:23 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-19 13:34:23 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-19 13:34:23 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-19 10:29:46 --> Severity: Compile Error --> Cannot redeclare Admin::dashboard() C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 81
ERROR - 2024-09-19 14:00:15 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-19 14:00:15 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-19 14:00:15 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-19 14:00:20 --> Severity: Warning --> Undefined variable $admissions C:\xampp\htdocs\mce_campus\application\views\admin\students.php 21
ERROR - 2024-09-19 14:00:20 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given C:\xampp\htdocs\mce_campus\application\views\admin\students.php 21
ERROR - 2024-09-19 14:01:58 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-19 14:01:58 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-19 14:01:58 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-19 14:16:02 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 14:16:02 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 14:16:46 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 14:16:46 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 14:19:17 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 14:19:17 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 14:21:43 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 14:21:43 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 14:21:44 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 14:21:44 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 14:22:19 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 14:22:19 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 10:52:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-09-19 10:52:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-09-19 10:52:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2024-09-19 14:23:09 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 14:23:09 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 14:43:32 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 14:43:32 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 14:43:43 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 14:43:43 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 14:45:22 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 14:45:22 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 14:45:48 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 14:45:48 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 14:48:08 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 14:48:08 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 11:23:37 --> 404 Page Not Found: Student/students
ERROR - 2024-09-19 14:53:38 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-19 14:53:38 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-19 14:53:38 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-19 14:55:34 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-19 14:55:34 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-19 14:55:34 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-19 14:55:45 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-19 14:55:45 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-19 14:55:45 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-19 11:27:12 --> 404 Page Not Found: Student/profile
ERROR - 2024-09-19 14:57:17 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-19 14:57:17 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-19 14:57:17 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-19 14:57:19 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-19 14:57:19 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-19 14:57:19 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-19 11:27:51 --> 404 Page Not Found: Student/students
ERROR - 2024-09-19 14:57:55 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-19 14:57:55 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-19 14:57:55 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-19 15:00:56 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-19 15:00:56 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-19 15:00:56 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-19 11:30:59 --> 404 Page Not Found: Student/students
ERROR - 2024-09-19 15:01:01 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-19 15:01:01 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-19 15:01:01 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-19 15:01:03 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-19 15:01:03 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-19 15:01:03 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-19 11:31:21 --> 404 Page Not Found: Student/students
ERROR - 2024-09-19 15:01:25 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-19 15:01:25 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-19 15:01:25 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-19 15:01:25 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-19 15:01:25 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-19 15:01:25 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-19 11:31:29 --> 404 Page Not Found: Student/students
ERROR - 2024-09-19 15:05:17 --> Severity: Warning --> Undefined variable $educations_details C:\xampp\htdocs\mce_campus\application\views\student\profile.php 945
ERROR - 2024-09-19 15:05:17 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given C:\xampp\htdocs\mce_campus\application\views\student\profile.php 945
ERROR - 2024-09-19 15:05:28 --> Severity: Warning --> Undefined variable $educations_details C:\xampp\htdocs\mce_campus\application\views\student\profile.php 945
ERROR - 2024-09-19 15:05:28 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given C:\xampp\htdocs\mce_campus\application\views\student\profile.php 945
ERROR - 2024-09-19 11:41:41 --> 404 Page Not Found: Student/admissiondetails
ERROR - 2024-09-19 12:27:29 --> 404 Page Not Found: Student/admissiondetails
ERROR - 2024-09-19 15:58:03 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 15:59:22 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:01:14 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:02:16 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:05:19 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:06:39 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:06:51 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:07:22 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:07:30 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:07:39 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:08:51 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:09:37 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:09:41 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:11:09 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:12:48 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:12:59 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:19:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:25:51 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:25:51 --> Severity: Warning --> Undefined variable $mobile C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 33
ERROR - 2024-09-19 16:25:51 --> Severity: Warning --> Undefined variable $email C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 42
ERROR - 2024-09-19 16:25:51 --> Severity: Warning --> Undefined variable $aadhaar C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 51
ERROR - 2024-09-19 16:26:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:26:54 --> Severity: Warning --> Undefined variable $mobile C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 33
ERROR - 2024-09-19 16:26:54 --> Severity: Warning --> Undefined variable $email C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 42
ERROR - 2024-09-19 16:26:54 --> Severity: Warning --> Undefined variable $aadhaar C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 51
ERROR - 2024-09-19 16:28:05 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:28:06 --> Severity: Warning --> Undefined variable $mobile C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 33
ERROR - 2024-09-19 16:28:06 --> Severity: Warning --> Undefined variable $email C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 42
ERROR - 2024-09-19 16:28:06 --> Severity: Warning --> Undefined variable $aadhaar C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 51
ERROR - 2024-09-19 16:28:20 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:28:21 --> Severity: Warning --> Undefined variable $mobile C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 33
ERROR - 2024-09-19 16:28:21 --> Severity: Warning --> Undefined variable $email C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 42
ERROR - 2024-09-19 16:28:21 --> Severity: Warning --> Undefined variable $aadhaar C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 51
ERROR - 2024-09-19 16:28:54 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:28:54 --> Severity: Warning --> Undefined variable $mobile C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 33
ERROR - 2024-09-19 16:31:10 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:31:10 --> Severity: Warning --> Undefined variable $mobile C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 34
ERROR - 2024-09-19 16:32:55 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:35:08 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:35:09 --> Severity: Warning --> Undefined variable $email C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 42
ERROR - 2024-09-19 16:35:09 --> Severity: Warning --> Undefined variable $aadhaar C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 51
ERROR - 2024-09-19 16:37:41 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:37:41 --> Severity: Warning --> Undefined property: stdClass::$aadhar C:\xampp\htdocs\mce_campus\application\controllers\Student.php 157
ERROR - 2024-09-19 16:37:41 --> Severity: Warning --> Undefined variable $aadhaar C:\xampp\htdocs\mce_campus\application\views\student\personal_details.php 51
ERROR - 2024-09-19 16:38:28 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:40:30 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:56:56 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:57:10 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:57:15 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:57:25 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:57:34 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:57:36 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:58:28 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 13:28:28 --> 404 Page Not Found: Student/parentdetails
ERROR - 2024-09-19 16:58:31 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:58:34 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:58:37 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:58:45 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:58:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 13:28:52 --> 404 Page Not Found: Student/parentdetails
ERROR - 2024-09-19 16:58:58 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:59:28 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:59:33 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:59:40 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 16:59:58 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 17:00:47 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 17:01:08 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 17:01:20 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 17:01:31 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 17:05:48 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 17:06:26 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 17:12:19 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-19 17:12:19 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-19 17:12:19 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-19 17:12:20 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 17:12:20 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 17:12:43 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-19 17:12:43 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-19 17:12:43 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-19 17:13:20 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 17:13:20 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 17:21:43 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 17:21:43 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 13:52:02 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 13:52:02 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 13:52:02 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-19 13:52:02 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-19 13:52:02 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 13:52:02 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-19 13:52:02 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-19 13:52:02 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-19 13:52:02 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-19 13:52:02 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 13:52:02 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-19 13:52:02 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-19 13:52:02 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-19 13:52:02 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-19 13:52:02 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-19 13:52:02 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-19 13:52:02 --> 404 Page Not Found: Assets/js
ERROR - 2024-09-19 17:23:21 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 17:23:21 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 13:53:44 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 13:53:44 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 13:53:44 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 13:53:44 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 17:25:27 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 17:25:33 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 17:27:18 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 17:27:18 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 13:57:42 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 13:57:42 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 13:57:42 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 13:57:42 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 17:31:17 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 17:31:17 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 14:01:36 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:01:36 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:01:36 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:01:36 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 17:34:36 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 17:34:36 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 14:05:02 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:05:02 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:05:02 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:05:02 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 17:39:34 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 17:39:34 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 14:10:24 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:10:24 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:10:24 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:10:24 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 17:40:59 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 17:40:59 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 14:11:48 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:11:48 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:11:48 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:11:48 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 17:42:07 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 17:42:07 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 14:12:58 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:12:58 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:12:58 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:12:59 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 17:44:22 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 17:44:22 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 17:44:46 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 14:14:46 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:14:46 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:14:46 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:14:46 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 17:46:58 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-19 17:46:58 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-19 17:46:58 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-19 14:16:58 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:16:58 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:16:58 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:16:58 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:17:00 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:17:00 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:17:00 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:17:00 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 17:47:01 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 17:47:01 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 17:47:25 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-19 17:47:25 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-19 17:47:25 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-19 14:17:27 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:17:27 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:17:27 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:17:28 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 17:48:29 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-19 17:48:29 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-19 17:48:29 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-19 17:48:34 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 17:49:01 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 17:49:13 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-19 17:49:13 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-19 17:49:13 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-19 14:19:13 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:19:13 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:19:13 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:19:13 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:19:15 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:19:15 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:19:15 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:19:15 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 17:49:21 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 17:49:21 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 14:19:44 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:19:44 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:19:44 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:19:44 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 17:53:07 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-19 17:53:07 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-19 17:53:07 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-19 17:53:10 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 17:53:15 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 17:53:17 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 18:05:15 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-19 18:05:15 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-19 18:05:15 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-19 18:13:01 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 18:13:01 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 14:43:27 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:43:27 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:43:27 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:43:27 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 18:15:33 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 18:15:33 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 14:45:53 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:45:53 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:45:53 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:45:53 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 18:16:33 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 18:16:33 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 14:46:33 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:46:33 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:46:33 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:46:33 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 18:16:46 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 20
ERROR - 2024-09-19 18:16:46 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 25
ERROR - 2024-09-19 18:16:46 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\admin\changepassword.php 30
ERROR - 2024-09-19 14:46:46 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:46:46 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:46:46 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:46:46 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 18:16:47 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 18:16:47 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 14:46:48 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:46:48 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:46:48 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:46:48 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:46:49 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:46:49 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:46:49 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:46:49 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 18:16:49 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 18:16:49 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 14:46:50 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:46:50 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:46:50 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:46:50 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 18:17:12 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 18:17:12 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 14:47:38 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:47:38 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:47:38 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:47:38 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 18:27:19 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 18:27:19 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 14:57:43 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:57:43 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:57:43 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:57:43 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 18:28:40 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 18:28:40 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 14:59:02 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:59:02 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:59:02 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 14:59:02 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 18:29:33 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 18:30:21 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 18:30:36 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 18:31:06 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 18:31:19 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 18:31:33 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 18:31:37 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 18:31:41 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 18:32:01 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 18:33:10 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 18:33:26 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 18:33:48 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 18:33:51 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 18:45:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 18:52:10 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 18:52:21 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 19:02:03 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 95
ERROR - 2024-09-19 19:02:03 --> Severity: Warning --> Undefined variable $status C:\xampp\htdocs\mce_campus\application\controllers\Admin.php 100
ERROR - 2024-09-19 15:32:23 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 15:32:23 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 15:32:23 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 15:32:23 --> 404 Page Not Found: Admin/assets
ERROR - 2024-09-19 19:07:34 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
ERROR - 2024-09-19 19:12:30 --> Severity: Warning --> Undefined variable $oldpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 22
ERROR - 2024-09-19 19:12:30 --> Severity: Warning --> Undefined variable $newpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 27
ERROR - 2024-09-19 19:12:30 --> Severity: Warning --> Undefined variable $confirmpassword C:\xampp\htdocs\mce_campus\application\views\student\changepassword.php 32
ERROR - 2024-09-19 19:12:38 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\mce_campus\application\controllers\Student.php 101
